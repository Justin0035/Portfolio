<?php
session_start();
require_once("connect-db.php");

if (isset($_POST['cart_item_id'])) {
    $cart_item_id = $_POST['cart_item_id'];

    $sql = "DELETE FROM cart_items WHERE cart_item_id = :cart_item_id";
    $statement = $db->prepare($sql);
    $statement->bindValue(":cart_item_id", $cart_item_id);
    $statement->execute();
}

header("Location: cart.php?removed=1");
exit;
?>