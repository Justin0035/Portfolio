<?php
session_start();

    if(!isset($_SESSION['admin-login'])){
        header("Location: menu.php");
        exit();
    }
    $message = "";
    require_once("connect-db.php");
    $sql = "SELECT * FROM orders ORDER BY order_id DESC";
    $statement = $db->prepare($sql);
    $statement->execute();
    $orders = $statement->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.php"?>
        <article>
        <h1>Past Orders</h1>
            <h5>Here you can view all the past orders</h5>
            <?php if (count($orders) > 0): ?>
                <?php $counter = 1; ?>
                <?php foreach ($orders as $order): ?>
                    <div class="order-summary">
                        <h3>Order #<?= $counter++ ?></h3>
                        <?php
                            $orderSql = "SELECT oi.quantity, f.food_name, f.food_price 
                                         FROM order_items oi 
                                         JOIN food f ON oi.food_id = f.food_id 
                                         WHERE oi.order_id = :order_id";
                            $orderStmt = $db->prepare($orderSql);
                            $orderStmt->bindValue(":order_id", $order['order_id']);
                            $orderStmt->execute();
                            $items = $orderStmt->fetchAll();

                            $orderTotal = 0;
                            foreach ($items as $item):
                                $subtotal = $item['food_price'] * $item['quantity'];
                                $orderTotal += $subtotal;
                        ?>
                            <li>
                                <?= htmlspecialchars($item['food_name']) ?> x <?= $item['quantity'] ?> 
                                - $<?= number_format($subtotal, 2) ?>
                            </li>
                        <?php endforeach; ?>
                        <strong><br>Total: $<?= number_format($orderTotal, 2) ?></strong>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>You have not placed any orders yet.</p>
            <?php endif; ?>
            </article>
        
        <?php include "footer_taco.html"?>
    </div>
</body>
</html>