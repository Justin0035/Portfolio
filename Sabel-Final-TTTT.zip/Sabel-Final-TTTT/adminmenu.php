<?php
session_start();
$message = "";
require_once("connect-db.php");

    if(!isset($_SESSION['admin-login'])){
        header("Location: menu.php");
        exit();
    }

    $sql1 = "select * from food where status = 'Active'";

    $statement = $db->prepare($sql1);

    if($statement->execute()){
        $food = $statement->fetchAll();
        $statement->closeCursor();
        $message = "<h3>Items successfully retrieved.</h3>";
    }else{
        $message = "<h3>Error retrieving items.</h3>";
    }

$grouped_food = [
    "tacos" => [],
    "burritos" => [],
    "quesadillas" => [],
    "sides" => [],
    "drinks" => [],
];

foreach ($food as $f) {
    $food_cat = $f["food_cat"];
    if (isset($grouped_food[$food_cat])) {
        $grouped_food[$food_cat][] = $f;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.php"?>
        <article>
        <!-- Side Nav Bar -->
        <div class="categories">
            <div class="categories-inner">
                <h3 class="categories-menu">Menu</h3>
                <div class="category-item">
                    <a href="#choice1">Tacos</a>
                </div>
                <div class="category-item">
                    <a href="#choice2">Burritos</a>
                </div>
                <div class="category-item">
                    <a href="#choice3">Quesadillas</a>
                </div>
                <div class="category-item">
                    <a href="#choice4">Sides</a>
                </div>
                <div class="category-item">
                    <a href="#choice5">Drinks</a>
                </div>
            </div>
        </div>  
            <form action="addmenu.php" method="GET">
            <button class="addtoorder bigbutton" type="submit">Add New Food</button>
            </form>
            <form action="remove-menuitem.php" method="GET">
            <button class="addtoorder deleteitem bigbutton" type="submit">Bring Back Deleted Food</button>
            </form>
        <?php
        $counter = 1;
        ?>
        <?php foreach ($grouped_food as $food_cat => $food): ?>
            <div>
                <h2 id="choice<?php echo $counter; ?>" class="foodclasses"><?php echo strtoupper($food_cat); ?></h2>
            </div>
            
            <?php if (!empty($food)): ?>
                <div class="menu1">
                <?php foreach ($food as $f): ?>
                    <div class="menusection">
                        <img class="menuimg" src="<?php echo htmlspecialchars('images/' . $f['food_img']); ?>" alt="Food Image">
                            <p class="menutext"><?php echo $f["food_name"]; ?><span class="menuprice"><?php echo "$" . $f["food_price"]; ?></span></p>
                            <p class="menudesc"><?php echo $f["food_desc"]; ?></p>
                            <form action="updatemenu.php" method="GET">
                                <input type="hidden" name="food_id" value="<?php echo $f["food_id"]; ?>">
                                <button class="addtoorder updateitem" type="submit">Update/Remove Item</button>
                            </form>
                            <p class="menucal">Calories: <?php echo $f["food_cal"]; ?></p>
                            <!--Update classes for buttons and make them different color-->
                </form></td>
                    </div>     
                    
                <?php endforeach; ?>
                </div>
            <?php else: ?>
                
            <?php endif; ?>
            <?php $counter++; ?>
        <?php endforeach; ?>

        </article>
        
        <?php include "footer_taco.html"?>
    </div>

</body>
</html>
