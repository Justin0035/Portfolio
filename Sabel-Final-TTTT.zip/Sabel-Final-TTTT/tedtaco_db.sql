-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 11, 2025 at 04:36 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tedtaco_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `cart_id` int NOT NULL,
  `customer_id` int DEFAULT NULL,
  `session_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`cart_id`, `customer_id`, `session_id`) VALUES
(1, 5, 'e438c329dd911d5423bfcc4bb4d0652a'),
(2, NULL, '26a036bb9cc7a4a17954dc8c1328fd43'),
(3, 7, '26a036bb9cc7a4a17954dc8c1328fd43'),
(4, NULL, '23c5f07dfa8a5e160793b47ecef9c61f'),
(7, NULL, '40e4fa47af4eaf588072da886d161cdb'),
(8, 8, '40e4fa47af4eaf588072da886d161cdb'),
(11, NULL, '7a6640e9a626cd48023586610506472d'),
(12, 9, '7a6640e9a626cd48023586610506472d'),
(13, NULL, '801cf2cf936ea27bd362eb37551ec115'),
(14, 10, '801cf2cf936ea27bd362eb37551ec115'),
(19, NULL, '3d9bc0a43559d6de48adc4852383e403'),
(20, 11, '3d9bc0a43559d6de48adc4852383e403'),
(23, NULL, 'e694622a1d6c2b7f4197a4bf5abc1b77'),
(24, 12, 'e694622a1d6c2b7f4197a4bf5abc1b77'),
(25, NULL, 'a70997997903a4a33584ea23e4ecd32c'),
(26, 14, 'a70997997903a4a33584ea23e4ecd32c'),
(27, NULL, '98511349bb6cab5ab1ea08079457e634'),
(28, 15, '98511349bb6cab5ab1ea08079457e634'),
(32, NULL, '28cb9cf3d91689ae1b04b9dde4dd2993'),
(33, 16, '28cb9cf3d91689ae1b04b9dde4dd2993'),
(34, NULL, '790ee6baeecf4449be0eae9cc2a8922d'),
(35, 17, '790ee6baeecf4449be0eae9cc2a8922d'),
(37, NULL, '8ff97ceeb495a9ad6e2732bf5e0b7ede'),
(39, NULL, '9509c7140b3ebe59a38cf4ba528c27a9'),
(40, 18, '9509c7140b3ebe59a38cf4ba528c27a9'),
(41, NULL, '7b23c77a7175c6696fbec7b70d0fd49e'),
(42, 19, '7b23c77a7175c6696fbec7b70d0fd49e'),
(43, NULL, '4bd822ab79e4cb00803f4ae3928fc6fe'),
(44, 20, '4bd822ab79e4cb00803f4ae3928fc6fe'),
(45, NULL, '288902558c64409a2da190e6e4bd167f'),
(46, NULL, 'f386e0c1b3df55a31780cc84ab908652'),
(47, 21, 'f386e0c1b3df55a31780cc84ab908652'),
(48, 22, NULL),
(49, 23, NULL),
(52, 6, NULL),
(54, NULL, NULL),
(55, 25, NULL),
(56, 26, NULL),
(59, 27, NULL),
(60, NULL, '54202eeabfe3c10aa5b7b587c20e650c');

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `cart_item_id` int NOT NULL,
  `cart_id` int DEFAULT NULL,
  `food_id` int DEFAULT NULL,
  `quantity` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cart_items`
--

INSERT INTO `cart_items` (`cart_item_id`, `cart_id`, `food_id`, `quantity`) VALUES
(11, 2, 8, 1),
(13, 2, 15, 2),
(14, 3, 9, 1),
(17, 4, 15, 1),
(18, 4, 23, 2),
(19, 4, 1, 1),
(26, 3, 17, 1),
(27, 3, 10, 1),
(28, 3, 7, 1),
(29, 3, 8, 1),
(34, 7, 9, 1),
(35, 7, 16, 1),
(36, 8, 11, 1),
(39, 8, 21, 4),
(41, 11, 21, 1),
(43, 12, 6, 1),
(73, 19, 23, 1),
(74, 19, 19, 4),
(75, 19, 16, 1),
(84, 23, 8, 2),
(86, 25, 1, 1),
(90, 27, 6, 2),
(91, 27, 17, 1),
(92, 27, 23, 2),
(106, 33, 6, 3),
(107, 33, 16, 1),
(109, 33, 9, 1),
(110, 33, 7, 1),
(112, 34, 9, 2),
(113, 34, 19, 1),
(116, 35, 1, 2),
(121, 39, 14, 1),
(122, 39, 15, 2),
(123, 39, 23, 1),
(125, 40, 1, 1),
(126, 40, 6, 1),
(128, 41, 16, 1),
(130, 43, 15, 1),
(132, 43, 1, 3),
(135, 45, 6, 3),
(137, 46, 6, 2),
(138, 46, 9, 1),
(142, 48, 18, 1),
(144, 48, 14, 1),
(145, 48, 1, 1),
(146, 48, 10, 1),
(150, 49, 10, 2),
(152, 49, 6, 1),
(158, 52, 1, 1),
(159, 52, 6, 1),
(166, 28, 6, 1),
(167, 28, 1, 2),
(168, 54, 9, 2),
(169, 55, 29, 1),
(170, 55, 13, 1),
(171, 55, 6, 2),
(172, 55, 28, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int NOT NULL,
  `customername` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `customeremail` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `customerusername` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `customerpassword` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `card_num` int NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `postal` int NOT NULL,
  `state` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customername`, `customeremail`, `customerusername`, `customerpassword`, `card_num`, `address`, `city`, `postal`, `state`) VALUES
(3, 'Larry Fam', 'LarryPerry@gmail.com', 'Larry4290', '$2y$10$AUBGuxiXoDXJ4aGRgjdv/.VkRdGrgV/fsMGS7c.i8pRPcM.iGd.TG', 8341, '895 Upton Avenue', 'sheboygan', 12367, 'CA'),
(4, 'Aidan', 'Aidan45speed@gmail.com', 'Aidaniscool', '$2y$10$7GI7nRpRAZ0L2ZdRqgvibeQY5rxh4QVQgSdZIS/TnS2uI9Tblw7ta', 6351, '1708 Bernardo Street', 'sheboygan', 84163, 'NE'),
(5, 'Max Rodger', 'Maxpower@gmail.com', 'Maxpower99', '$2y$10$xkHo3h6V.AXNYEYLH3dn9OX1.xaMGH71hNNJH34yIlhwVOkaYxRxG', 8196, '815 Fairview Drive', 'Memphis', 96102, 'TN'),
(6, 'Teddy ', 'TedTacosOwner91@gmail.com', 'TedAdmin8901', '$2y$10$bvkUlWtRdpu1saCgtLXhVueBuFBT2p3waNk7EVNinco1uyWURGkJu', 3790, '246 South Milwaukee', 'Fond Du Lac', 59815, 'WI'),
(8, 'Todd Kwekkboom', 'ToddGood@yahoo.com', 'Toddthat25', '$2y$10$icYv4ZbmI3rD8GaTg6oS2.F1R1Z9F/jZe5iXWpgOcTCUEJAeEHmvG', 8595, '445 Rhode Ave', 'KML', 95122, 'MA'),
(9, 'Ivan hamm', 'Ivanrthis@gmail.com', 'Ivan5123', '$2y$10$sIXTkRGPIOKdUIZpS344NuiHLBzeXmNn1DQcPqY7r6WtyfBsoPQga', 1111, '238 Heritage Road', 'Fresno', 95125, 'CA'),
(10, 'Maddy Goodman', 'MaddyPan12@gmail.com', 'Maddy91028', '$2y$10$EvFvkMijSWAAq3/Gn2./.uUjSUIKzHPo/TxP8QzEAeLA8A2Di41iK', 1823, '451 Michigan RD', 'Green Bay', 62515, 'PE'),
(12, 'Timmy Cohn', 'Timmy23@gmail.com', 'Timmytest65', '$2y$10$Pg4u40yG1elPGp128DCpcejCPsOpSsiZeeriJ6S06.cUCdp5RwSBi', 4262, '9152 House lane', 'Kohler', 36123, 'RI'),
(13, 'goood ee', 'oerfo@gmail.com', 'Aidaniscool', '$2y$10$6lcMATYQFMJZgMp9/4WdPuTgs8EF6kc0L4Tpdo5mAKVgFISOGhDUq', 2131, '238 Heritage Road', 'Sheboygan', 23515, 'CA'),
(15, 'Todd Kwekkboom', 'bobby45@gmail.com', 'Fredgood2', '$2y$10$fLN1D52SVoq.KIQVK9lUL.5dEx7ABaPmbhRExTrJfyhUCp2GrVOie', 9361, '445 Rhode Ave', 'New Albany', 95122, 'FL'),
(16, 'Kim', 'MaddyPat12@gmail.com', 'Noobbye1', '$2y$10$g55N6R4ZWoovZWOsMfIWTuzgjfpdoVILFh9VuvULosrlWOSBeW9wW', 8231, '895 Upton Avenue', 'KML', 62515, 'ME'),
(17, 'Kim', 'LarryPerry@gmail.com', 'Goodbye2', '$2y$10$FOZuus.vEFbiDgqWpAHMz.d3C7ruXcxqmNKI0MQbFRvHQDw/2CYca', 1111, '238 Heritage Road', 'Fresno', 62515, 'FL'),
(18, 'Tony tilts', 'Tonyt2@gmail.com', 'Tonyfinal', '$2y$10$CY6x9pZChXsjOK6chRhI1e8L/O.AWbqUO4E3P4HPUwDiItWROsn/y', 9361, '895 Upton Avenue', 'Fresno', 95122, 'MA'),
(19, 'Kim', 'MaddyPat12@gmail.com', 'ju123', '$2y$10$lHYdbb5Kw1t7OnFHZV9Y8.QxIOL1eUq2VZpACJbenNK.2R05u9qHK', 8231, '895 Upton Avenue', 'KML', 95811, 'ME'),
(20, 'Kim', 'MaddyPat12@gmail.com', 'Bye23', '$2y$10$oWEJBI7uHUFsANiAptLyqOV/AaKaiNfwWZuV.uFwXY2Mpfe1nzUM.', 9361, '451 Michigan Ave', 'New Albany', 95122, 'MA'),
(21, 'Larry Fam', 'LarryPerry@gmail.com', 'Just2131', '$2y$10$wDp7lPHauIp06J703s1ZhuPf0SkIZ1Luyqf.p48SCOsYa6c4pIRTS', 8231, '451 Michigan Ave', 'KML', 95122, 'MA'),
(24, 'Maddy Goodman', 'LarryPerry@gmail.com', 'Maddy91028', '$2y$10$Qr6EuTmOWai4rfx9sTTNCu.svWrPb2UZ5iQxtYaTGtgrB2ROh1NrS', 8231, '895 Upton Avenue', 'sheboygan', 23515, 'OR'),
(25, 'Bobby', 'MaddyPat12@gmail.com', 'Queen132', '$2y$10$F2D2vwgvMksZWLF3J/LJY.YwZN/GhUlZNFMJWN6bIUFZnq4x.2pam', 8231, '895 Upton Avenue', 'sheboygan', 62515, 'MA'),
(26, 'Yemen', 'thifsdw@gmail.com', 'Jamestest7', '$2y$10$zjCC.q9.DxeqdcKwA2/jNuiJDyp/SYHnRK204BqtdOXjHTJbVGW7S', 7341, '246 South Milwaukee', 'Wind', 95122, 'OR'),
(27, 'Final Guy', 'Finalthis@gmail.com', 'Finalguy', '$2y$10$ytDXpltoEJGkWM0bFStB0eLH4tSA.bNR16lk2uMdevgcQpDI70E/6', 9125, '815 Fairview Drive', 'New York', 91561, 'WI');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `food_id` int NOT NULL,
  `food_img` varchar(255) NOT NULL,
  `food_cat` varchar(50) NOT NULL,
  `food_name` varchar(100) NOT NULL,
  `food_price` decimal(10,2) NOT NULL,
  `food_desc` varchar(200) NOT NULL,
  `food_cal` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`food_id`, `food_img`, `food_cat`, `food_name`, `food_price`, `food_desc`, `food_cal`, `status`) VALUES
(1, 'taco1.jpg', 'tacos', 'Soft Shell Tacos (3)', '7.49', 'Classic flour tortilla filled with seasoned beef, lettuce, tomatoes and cheese.', '740', 'Active'),
(6, 'taco3.jpg', 'tacos', 'Alaska Flounder Fish Tacos (2)', '7.29', 'Crispy fried flounder topped with fresh slaw, lettuce and tomatoes', '810', 'Active'),
(7, 'taco4.jpg', 'tacos', 'Stuffed Grilled Tacos (2)', '7.29', 'Loaded with beef, cheese, and grilled to perfection ', '800', 'Active'),
(8, 'taco5.jpg', 'tacos', 'Fiesta Chicken Softshell Tacos (3)', '8.99', 'Tasty grilled chicken filled with fresh topping', '850', 'Active'),
(9, 'taco6.jpg', 'tacos', 'Nacho Taco Bravo (2)', '7.99', 'Loaded with seasoned beef, cheese sauce, lettuce, tomatoes and cheese', '780', 'Active'),
(10, 'burrito1.jpg', 'burritos', 'Bean Burrito (2)', '6.29', 'Stuffed with refried beans, cheese and mild sauce', '800', 'Active'),
(11, 'burrito2.jpg', 'burritos', 'Chicken Grilled Burrito (1)', '4.49', 'Grilled tortillla filled with seasoned chicken and cheese', '490', 'Active'),
(13, 'burrito4.jpg', 'burritos', 'Super Burrito (1)', '4.99', 'Packed with beef, beans, lettuce, tomatoes, and cheese', '750', 'Active'),
(14, 'ques1.jpg', 'quesadillas', 'Four Cheese Quesadilla', '5.99', 'Four Toasted torillas filled with a blend of four melted cheese', '450', 'Active'),
(15, 'ques2.jpg', 'quesadillas', 'Four Cheese Chicken Quesadilla', '6.99', 'Four Toasted torillas with grilled chicken and melted cheeses', '610', 'Active'),
(16, 'ques3.jpg', 'quesadillas', 'Four Cheese Steak Quesadilla', '7.49', 'Four Toasted tortillas filled with juicy steak and melted cheeses', '630', 'Active'),
(17, 'side1.jpg', 'sides', 'Chips & Nacho Cheese', '3.99', 'Crispy tortilla chips served with warm nacho cheese', '370', 'Active'),
(18, 'side2.jpg', 'sides', 'Red Rice', '3.99', 'Lightly seasoned Mexican-style rice', '390', 'Active'),
(19, 'side3.jpg', 'sides', 'Refried Beans', '3.99', 'Slow-cooked beans topped with shredded cheese', '440', 'Active'),
(21, 'drink2.jpg', 'drinks', 'Pepsi', '2.99', 'That\'s What I Like', '320', 'Active'),
(23, 'drink4.jpg', 'drinks', 'Dr Pepper', '2.99', 'There\'s just more to it', '330', 'Active'),
(25, 'drink1.jpg', 'drinks', 'Starry', '2.99', 'Starry Hits Different', '320', 'Active'),
(26, 'drink3.jpg', 'drinks', 'Mountain Dew', '3.19', 'Do the Dew', '360', 'Active'),
(28, 'taco2.jpg', 'tacos', 'Crunchy Shell Tacos (3)', '7.69', 'Corn shell filled with seasoned beef, lettuce, tomatoes and cheese', '760', 'Active'),
(29, 'burrito3.jpg', 'burritos', 'Meat & Potato Burrito (1)', '4.49', 'Seasoned beef and crispy potatoes wrapped in a warm tortilla', '500', 'Active'),
(30, 'taco6.jpg', 'sides', 'drink soda', '7.49', 'hello', '520', 'Out'),
(31, 'taco1.jpg', 'tacos', 'Crunchy Shell Tacos (3)', '5.89', 'good for you', '760', 'Out'),
(32, 'taco4.jpg', 'drinks', 'Stuffed Grilled yummy', '2.99', 'Corn shell filled with seasoned beef, lettuce, tomatoes and cheese', '510', 'Out');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int NOT NULL,
  `customer_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`) VALUES
(4, 5),
(2, 10),
(3, 10),
(6, 10),
(13, 12),
(9, 15),
(10, 15),
(11, 15),
(12, 26),
(14, 27);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `order_item_id` int NOT NULL,
  `order_id` int DEFAULT NULL,
  `food_id` int DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`order_item_id`, `order_id`, `food_id`, `quantity`) VALUES
(4, 3, 19, 1),
(6, 4, 9, 2),
(8, 4, 1, 1),
(10, 4, 14, 1),
(11, 5, 19, 2),
(12, 5, 10, 1),
(13, 5, 23, 1),
(14, 6, 15, 1),
(16, 6, 1, 1),
(19, 7, 1, 2),
(20, 7, 23, 1),
(21, 7, 17, 1),
(23, 8, 11, 1),
(24, 9, 6, 1),
(25, 9, 7, 2),
(26, 9, 21, 1),
(27, 9, 9, 1),
(29, 9, 17, 1),
(30, 9, 1, 1),
(31, 10, 8, 1),
(32, 11, 8, 1),
(33, 11, 11, 1),
(35, 12, 1, 1),
(36, 12, 10, 2),
(37, 12, 29, 2),
(38, 13, 9, 1),
(39, 13, 32, 2),
(40, 13, 28, 1),
(41, 13, 21, 1),
(42, 14, 26, 2),
(43, 14, 1, 2),
(44, 14, 23, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`cart_item_id`),
  ADD KEY `cartrelationship` (`cart_id`),
  ADD KEY `foodrelationship2` (`food_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customerrelationship` (`customer_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `foodrelationship` (`food_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `cart_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `cart_item_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=188;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `food_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `order_item_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `cartrelationship` FOREIGN KEY (`cart_id`) REFERENCES `carts` (`cart_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `foodrelationship2` FOREIGN KEY (`food_id`) REFERENCES `food` (`food_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `customerrelationship` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`) ON DELETE CASCADE ON UPDATE RESTRICT;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `foodrelationship` FOREIGN KEY (`food_id`) REFERENCES `food` (`food_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
