<?php
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["type"] == "c"){
    $customer_id = $_POST["customer_id"];
    $customername = $_POST["customername"];
    $customeremail = $_POST["customeremail"];
    $customerusername = $_POST["customerusername"];
    $customerpassword = $_POST["customerpassword"];
    $card_num = $_POST["card_num"];
    $address = $_POST["address"];
    $city = $_POST["city"];
    $postal = $_POST["postal"];
    $state = $_POST["state"];

    $hashed_password = password_hash($customerpassword, PASSWORD_DEFAULT);

    require_once("connect-db.php");

    $sql = "UPDATE customers SET customername = :customername, customeremail = :customeremail, customerusername = :customerusername, card_num = :card_num, address = :address, city = :city, postal = :postal, state = :state";

    if (!empty($customerpassword)) {
        $sql .= ", customerpassword = :customerpassword";
        $hashed_password = password_hash($customerpassword, PASSWORD_DEFAULT);
        $includePassword = true;
    } else {
        $includePassword = false;
    }

    $sql .= " WHERE customer_id = :customer_id";

    $statement = $db->prepare($sql);

    $statement->bindValue(":customername", $customername);
    $statement->bindValue(":customeremail", $customeremail);
    $statement->bindValue(":customerusername", $customerusername);
    $statement->bindValue(":card_num", $card_num);
    $statement->bindValue(":address", $address);
    $statement->bindValue(":city", $city);
    $statement->bindValue(":postal", $postal);
    $statement->bindValue(":state", $state);
    $statement->bindValue(":customer_id", $customer_id);

    if ($includePassword) {
        $statement->bindValue(":customerpassword", $hashed_password);
    }

    if($statement->execute()){
        $statement->closeCursor();

        $customerMessage = "<h4>Your Account has been Updated. You will be redirected</h4>";
        ?>
        <script>
            window.location.href = 'setting.php?updated=1';
        </script>
    <?php
    }else{
        $customerMessage = "<h4>There was a problem updateing your account.</h4>";
    }
}
?>