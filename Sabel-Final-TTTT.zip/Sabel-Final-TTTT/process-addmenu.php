<?php
    session_start();
    $message = "";
    require_once("connect-db.php");

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $food_img = $_POST["food_img"];
        $food_cat = $_POST["food_cat"];
        $food_name = $_POST["food_name"];
        $food_price = $_POST["food_price"];
        $food_desc = $_POST["food_desc"];
        $food_cal = $_POST["food_cal"];
        $status = $_POST["status"];
        $success = true;
    }
    else{
        echo "<h4>Error getting information.</h4>";
    }

if($success){
        require_once("connect-db.php");
        // insert date into database //
        $sql = "insert into food (food_img, food_cat, food_name, food_price, food_desc, food_cal, status) values (:food_img, :food_cat, :food_name, :food_price, :food_desc, :food_cal, :status)";
        $statement = $db->prepare($sql);

        $statement->bindValue(":food_img", $food_img);
        $statement->bindValue(":food_cat", $food_cat);
        $statement->bindValue(":food_name", $food_name);
        $statement->bindValue(":food_price", $food_price);
        $statement->bindValue(":food_desc", $food_desc);
        $statement->bindValue(":food_cal", $food_cal);
        $statement->bindValue(":status", $status);

        if($statement->execute()){
            $statement->closeCursor();

            $customerMessage = "<h4>You request has been submitted. Your food item have been added to database!</h4>";
            ?>
            <script>
                window.location.href = 'adminmenu.php';
            </script>
        <?php
        }else{
            $customerMessage = "<h4>There was a problem adding your request.</h4>";
        }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>
<body>

</body>
</html>