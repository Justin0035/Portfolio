<?php
    session_start();
    if (isset($_SESSION['admin-login']) && $_SESSION['admin-login'] == "true" || isset($_SESSION['customer-login']) && $_SESSION['customer-login'] == "true") {
        echo "<h3 style='color:white;'>YOU ARE ALREADY LOGGED IN! YOU WILL BE REDIRECTED TO THE HOME PAGE IN 3 SECONDS</h3>";
        echo "<div style = '
                            position:fixed; 
                            z-index:10; 
                            background-color:rgba(0,0,0,.15); 
                            width:100vw; 
                            height:100vh; 
                            top:0; 
                            left:0;
                            ' >
                </div>";
        ?>
        <script>
            setTimeout(function() {
                window.location.href = 'index.php';
            }, 3000);
        </script>
    <?php
    }
?>
<!DOCTYPE html>
<htm lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
    <?php include "header_nav.php"?>
        <article>
            <h2>Create a Customer Account</h2>
                <form action="process-signup.php" method="POST">
                    <label>Full Name:</label>
                    <input class="pad" type="text" name="customername" required>
                    <label>Email:</label>
                    <input class="pad" type="text" name="customeremail" required><br>
                    <label>Username:</label>
                    <input class="pad" type="text" name="customerusername" required>
                    <label>Password:</label>
                    <input class="pad" type="password" name="customerpassword" required><br>
                    <label>Card Number (Last 4 digits):</label>
                    <input class="pad" type="text" pattern="^\d{4}$" name="card_num" required>
                    <label>Address:</label>
                    <input class="pad" type="text" name="address" required>
                    <label>City:</label>
                    <input class="pad" type="text" name="city" required><br>
                    <label>Postal Code (5-6 digits):</label>
                    <input class="pad" type="text" pattern="^\d{5,6}$" name="postal" required>
                    <label>State:</label>
                    <input class="pad" type="text" pattern="^[A-Za-z]*$" name="state" required><br><br>
                    <input class="subch" type="submit" value="Create my account">
                </form>

        </article>
        
        <?php include "footer_taco.html"?>
    </div>
</body>

</html>