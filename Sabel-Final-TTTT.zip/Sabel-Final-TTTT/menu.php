<?php
session_start();

    if(isset($_SESSION['admin-login'])){
        header("Location: adminmenu.php");
        exit();
    }
    $message = "";
    require_once("connect-db.php");

    $sql1 = "select * from food where status = 'Active'";

    $statement = $db->prepare($sql1);

    if($statement->execute()){
        $food = $statement->fetchAll();
        $statement->closeCursor();
        $message = "<h3>Items successfully retrieved.</h3>";
    }else{
        $message = "<h3>Error retrieving items.</h3>";
    }

$grouped_food = [
    "tacos" => [],
    "burritos" => [],
    "quesadillas" => [],
    "sides" => [],
    "drinks" => [],
];

foreach ($food as $f) {
    $food_cat = $f["food_cat"];
    if (isset($grouped_food[$food_cat])) {
        $grouped_food[$food_cat][] = $f;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.php"?>
        <article>
        <div class="categories">
            <div class="categories-inner">
                <h3 class="categories-menu">Menu</h3>
                <div class="category-item">
                    <a href="#choice1">Tacos</a>
                </div>
                <div class="category-item">
                    <a href="#choice2">Burritos</a>
                </div>
                <div class="category-item">
                    <a href="#choice3">Quesadillas</a>
                </div>
                <div class="category-item">
                    <a href="#choice4">Sides</a>
                </div>
                <div class="category-item">
                    <a href="#choice5">Drinks</a>
                </div>
            </div>
        </div>  
        <?php
        $counter = 1;
        ?>
        <?php foreach ($grouped_food as $food_cat => $food): ?>
            <div>
                <h2 id="choice<?php echo $counter; ?>" class="foodclasses"><?php echo strtoupper($food_cat); ?></h2>
            </div>
            
            <?php if (!empty($food)): ?>
                <div class="menu1">
                <?php foreach ($food as $f): ?>
                    <div class="menusection">
                        <img class="menuimg" src="<?php echo htmlspecialchars('images/' . $f['food_img']); ?>" alt="Food Image">
                            <p class="menutext"><?php echo $f["food_name"]; ?><span class="menuprice"><?php echo "$" . $f["food_price"]; ?></span></p>
                            <p class="menudesc"><?php echo $f["food_desc"]; ?></p>
                            <form action="process-cart.php" method="POST">
                                <input type="hidden" name="food_id" value="<?php echo $f["food_id"]; ?>">
                                <button class="addtoorder" type="submit">Add To Order</button>
                            </form>
                            <p class="menucal">Calories: <?php echo $f["food_cal"]; ?></p>
                    </div>     
                    
                <?php endforeach; ?>
                </div>
            <?php else: ?>
                
            <?php endif; ?>
            <?php $counter++; ?>
        <?php endforeach; ?>


<?php
// Was my original code that I use for testing
// Left it so you can see the images files
/*      <h2 id="choice1" class="foodclasses">Tacos</h2> 
        <div class="menu1"> 
            <div class="menusection">
                <div class="menuimg"><img src="images/taco1.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/softshell-taco/?menu=tacos--></div>
                <div class="menuprice">$7.49</div>
                <div class="menutext">Soft Shell Tacos (3)</div>
                <div class="menudesc">Classic flour tortilla filled with seasoned beef, lettuce, tomatoes and cheese.</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/taco2.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/crispy-taco/?menu=tacos--></div>
                <div class="menuprice">$7.49</div>
                <div class="menutext">Crunchy Shell Tacos (3)</div>
                <div class="menudesc">Corn shell filled with seasoned beef, lettuce, tomatoes and cheese</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/taco3.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/alaska-flounder-fish-taco/?menu=tacos--></div>
                <div class="menuprice">$7.29</div>
                <div class="menutext">Alaska Flounder Fish Tacos (2)</div>
                <div class="menudesc">Crispy fried flounder topped with fresh slaw, lettuce and tomatoes</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/taco4.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/stuffed-grilled-taco/?menu=tacos--></div>
                <div class="menuprice">$7.29</div>
                <div class="menutext">Stuffed Grilled Tacos (2)</div>
                <div class="menudesc">Loaded with beef, cheese, and grilled to perfection</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/taco5.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/new-fiesta-chicken-softshell-taco/?menu=tacos--></div>
                <div class="menuprice">$8.99</div>
                <div class="menutext">Fiesta Chicken Softshell Tacos (3)</div>
                <div class="menudesc">Tasty grilled chicken filled with fresh topping</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/taco6.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/nacho-taco-bravo/?menu=tacos--></div>
                <div class="menuprice">$7.99</div>
                <div class="menutext">Nacho Taco Bravo (2)</div>
                <div class="menudesc">Loaded with seasoned beef, cheese sauce, lettuce, tomatoes and cheese</div>
                <div class="addtoorder">Add To Order</div>
            </div> 
        </div>
        <h2 id="choice2" class="foodclasses">Burritos</h2> 
        <div class="menu1"> 
            <div class="menusection">
                <div class="menuimg"><img src="images/burrito1.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/bean-burrito/?menu=burritos--></div>
                <div class="menuprice">$6.29</div>
                <div class="menutext">Bean Burrito (2)</div>
                <div class="menudesc">Stuffed with refried beans, cheese and mild sauce</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/burrito2.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/grilled-burrito/?menu=burritos--></div>
                <div class="menuprice">$4.49</div>
                <div class="menutext">Chicken Grilled Burrito (1)</div>
                <div class="menudesc">Grilled tortillla filled with seasoned chicken and cheese</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/burrito3.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/meat-potato-burrito/?menu=burritos--></div>
                <div class="menuprice">$4.49</div>
                <div class="menutext">Meat & Potato Burrito (1)</div>
                <div class="menudesc">Seasoned beef and crispy potatoes wrapped in a warm tortilla</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/burrito4.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/super-burrito/?menu=burritos--></div>
                <div class="menuprice">$4.99</div>
                <div class="menutext">Super Burrito (1)</div>
                <div class="menudesc">Packed with beef, beans, lettuce, tomatoes, and cheese</div>
                <div class="addtoorder">Add To Order</div>
            </div>
        </div>
        <h2 id="choice3" class="foodclasses">Quesadillas</h2> 
        <div class="menu1"> 
            <div class="menusection">
                <div class="menuimg"><img src="images/ques1.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/new-four-cheese-quesadilla/?menu=quesadillas--></div>
                <div class="menuprice">$5.99</div>
                <div class="menutext">Four Cheese Quesadilla</div>
                <div class="menudesc">Four Toasted torillas filled with a blend of four melted cheese</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/ques2.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/new-four-cheese-chicken-quesadilla/?menu=quesadillas--></div>
                <div class="menuprice">$6.99</div>
                <div class="menutext">Four Cheese Chicken Quesadilla</div>
                <div class="menudesc">Four Toasted torillas with grilled chicken and melted cheeses</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/ques3.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/new-four-cheese-steak-quesadilla/?menu=quesadillas--></div>
                <div class="menuprice">$7.49</div>
                <div class="menutext">Four Cheese Steak Quesadilla</div>
                <div class="menudesc">Four Toasted torillas filled with juicy steak and melted cheeses</div>
                <div class="addtoorder">Add To Order</div>
            </div> 
        </div>
        <h2 id="choice4" class="foodclasses">Sides</h2> 
        <div class="menu1"> 
            <div class="menusection">
                <div class="menuimg"><img src="images/side1.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/chips-nacho-cheese/?menu=sides--></div>
                <div class="menuprice">$3.99</div>
                <div class="menutext">Chips & Nacho Cheese</div>
                <div class="menudesc">Crispy tortilla chips served with warm nacho cheese</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/side2.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/red-rice/?menu=sides--></div>
                <div class="menuprice">$3.99</div>
                <div class="menutext">Red Rice</div>
                <div class="menudesc">Lightly seasoned Mexican-style rice</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/side3.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/refried-beans/?menu=sides--></div>
                <div class="menuprice">$3.99</div>
                <div class="menutext">Refried Beans</dsupeiv>
                <div class="menudesc">slow-cooked beans topped with shredded cheese</div>
                <div class="addtoorder">Add To Order</div>
            </div> 
        </div>
        <h2 id="choice5" class="foodclasses">Drinks</h2> 
        <div class="menu1"> 
            <div class="menusection">
                <div class="menuimg"><img src="images/drink1.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/starry/?menu=beverages--></div>
                <div class="menuprice">$2.99</div>
                <div class="menutext">Starry</div>
                <div class="menudesc">Starry Hits Different</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/drink2.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/pepsi/?menu=beverages--></div>
                <div class="menuprice">$2.99</div>
                <div class="menutext">Pepsi</div>
                <div class="menudesc">That's What I Like</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/drink3.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/mountain-dew/?menu=beverages--></div>
                <div class="menuprice">$2.99</div>
                <div class="menutext">Mountain Dew</div>
                <div class="menudesc">Do the Dew</div>
                <div class="addtoorder">Add To Order</div>
            </div>
            <div class="menusection">
                <div class="menuimg"><img src="images/drink4.jpg" alt="Ted's Tasty Tacos Truck"><!--https://tacojohns.com/menu/dr-pepper/?menu=beverages--></div>
                <div class="menuprice">$2.99</div>
                <div class="menutext">Dr Pepper</div>
                <div class="menudesc">There's just more to it</div>
                <div class="addtoorder">Add To Order</div>
            </div>
        </div>

*/   ?>        
        </article>
        
        <?php include "footer_taco.html"?>
    </div>
</body>
</html>