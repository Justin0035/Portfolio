<?php
    session_start();
    if (isset($_SESSION['admin-login']) && $_SESSION['admin-login'] == "true" || isset($_SESSION['customer-login']) && $_SESSION['customer-login'] == "true") {
        echo "<h3 style='color:white;'>YOU ARE ALREADY LOGGED IN! YOU WILL BE REDIRECTED TO THE HOME PAGE IN 3 SECONDS</h3>";
        echo "<div style = '
                            position:fixed; 
                            z-index:10; 
                            background-color:rgba(0,0,0,.15); 
                            width:100vw; 
                            height:100vh; 
                            top:0; 
                            left:0;
                            ' >
                </div>";
        ?>
        <script>
            setTimeout(function() {
                // Don't allow user to go on login back so you can't login twice
                window.location.href = 'index.php';
            }, 3000);
        </script>
    <?php
    }
?>
<!DOCTYPE html>
<htm lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.php"?>
        <article>
            <h2>Customer Login</h2>
                <form action="process-login.php" method="POST">
                    <label>Username:</label>
                    <input class="pad" type="text" name="customerusername" required>
                    <label>Password:</label>
                    <input class="pad" type="password" name="customerpassword" required>
                    <input class="subch" type="submit" value="Login">
                </form>

        </article>
        
        <?php include "footer_taco.html"?>
    </div>
</body>
</html>