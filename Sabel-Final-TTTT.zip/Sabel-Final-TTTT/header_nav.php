<?php
    if(session_status() !== PHP_SESSION_ACTIVE){
        session_start();
    }else{// logo https://order.online/store/ted%E2%80%99s-tacos-&-cantina-oklahoma-city-1102221/?hideModal=true
        if(isset($_SESSION["admin-login"]) && $_SESSION["admin-login"] == true){
            echo '
                <header>
                    <h1>Welcome Admin To Ted\'s Tasty Taco Truck</h1>
                </header>
                <nav>
                    <ul>
                        <li><a href="index.php"><img class="logoimg" src="images/logo1.jpg" alt="Ted\'s Tacos"></a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="adminmenu.php">Update Menu</a></li>
                        <li><a href="vieworders.php">View Orders</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </nav>
            ';
        }else if(isset($_SESSION["customer-login"]) && $_SESSION["customer-login"] == true){
            echo '
                <header>
                    <h1>Ted\'s Tasty Taco Truck</h1>
                </header>
                <nav>
                    <ul>
                        <li><a href="index.php"><img class="logoimg" src="images/logo1.jpg" alt="Ted\'s Tacos"></a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="menu.php">Menu</a></li>
                        <li><a href="cart.php">Cart</a></li>
                        <li><a href="setting.php">Setting</a></li>
                        <li><a href="logout.php">Login Out</a></li>
                    </ul>
                </nav>
            ';
        }else{
            echo '
                <header>
                    <h1>Ted\'s Tasty Taco Truck</h1>
                </header>
                <nav>
                    <ul>
                        <li><a href="index.php"><img class="logoimg" src="images/logo1.jpg" alt="Ted\'s Tacos"></a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="menu.php">Menu</a></li>
                        <li><a href="login.php">Login In</a></li>
                        <li><a href="signup.php">Sign Up</a></li>
                        <li><a href="cart.php">Cart</a></li>
                    </ul>
                </nav>
            ';
        }
    }
?>
