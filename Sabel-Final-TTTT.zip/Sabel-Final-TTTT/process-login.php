<?php
session_start();
require_once "connect-db.php";

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $customerusername = trim($_POST["customerusername"]);
    $customerpassword = trim($_POST["customerpassword"]);

    try{
        $sql = "SELECT customer_id, customerpassword FROM customers WHERE customerusername = :customerusername";
        $stmt = $db->prepare($sql);
        $stmt->bindParam(':customerusername', $customerusername);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if($customerusername == "TedAdmin8901" && password_verify($customerpassword, $user['customerpassword'])){
            $_SESSION['admin-login'] = "true";
            $_SESSION["customer_id"] = $user["customer_id"];
            echo "Login successful! Redirecting to home page...";
            header("Location: index.php");
        }else if($user && password_verify($customerpassword, $user['customerpassword'])){
            $_SESSION['customer-login'] = "true";
            $_SESSION["customer_id"] = $user["customer_id"];
            echo "Login successful! Redirecting to home page...";
            header("Location: menu.php");
        }else{
            header("Location: login.php");
        }
    } catch (PDOException $e){
        echo "Error";
    }
$customer_id = $_SESSION['customer_id'];
$guest_session_id = $_SESSION['guest_cart_id'] ?? null;

if ($guest_session_id) {
    $sql = "SELECT cart_id FROM carts WHERE session_id = :session_id";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(":session_id", $guest_session_id);
    $stmt->execute();
    $guest_cart = $stmt->fetch();

    $sql = "SELECT cart_id FROM carts WHERE customer_id = :customer_id";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(":customer_id", $customer_id);
    $stmt->execute();
    $user_cart = $stmt->fetch();

    if (!$user_cart) {
        if ($guest_cart) {
            $guest_cart_id = $guest_cart['cart_id'];
            $sql = "UPDATE carts SET customer_id = :customer_id, session_id = NULL WHERE cart_id = :cart_id";
            $stmt = $db->prepare($sql);
            $stmt->bindValue(":customer_id", $customer_id);
            $stmt->bindValue(":cart_id", $guest_cart_id);
            $stmt->execute();

            $user_cart_id = $guest_cart_id;
            $guest_cart = null; 
        } else {
            $sql = "INSERT INTO carts (customer_id) VALUES (:customer_id)";
            $stmt = $db->prepare($sql);
            $stmt->bindValue(":customer_id", $customer_id);
            $stmt->execute();
            $user_cart_id = $db->lastInsertId();
        }
    } else {
        $user_cart_id = $user_cart['cart_id'];
    }
    if ($guest_cart) {
        $guest_cart_id = $guest_cart['cart_id'];

        $sql = "SELECT food_id, quantity FROM cart_items WHERE cart_id = :cart_id";
        $stmt = $db->prepare($sql);
        $stmt->bindValue(":cart_id", $guest_cart_id);
        $stmt->execute();
        $guest_items = $stmt->fetchAll();

        foreach ($guest_items as $item) {
            $sql = "SELECT * FROM cart_items WHERE cart_id = :cart_id AND food_id = :food_id";
            $stmt = $db->prepare($sql);
            $stmt->bindValue(":cart_id", $user_cart_id);
            $stmt->bindValue(":food_id", $item['food_id']);
            $stmt->execute();
            $existing = $stmt->fetch();

            if ($existing) {
                $sql = "UPDATE cart_items SET quantity = quantity + :quantity WHERE cart_id = :cart_id AND food_id = :food_id";
            } else {
                $sql = "INSERT INTO cart_items (cart_id, food_id, quantity) VALUES (:cart_id, :food_id, :quantity)";
            }
            $stmt = $db->prepare($sql);
            $stmt->bindValue(":cart_id", $user_cart_id);
            $stmt->bindValue(":food_id", $item['food_id']);
            $stmt->bindValue(":quantity", $item['quantity']);
            $stmt->execute();
        }

        $db->prepare("DELETE FROM cart_items WHERE cart_id = :cart_id")->execute([':cart_id' => $guest_cart_id]);
        $db->prepare("DELETE FROM carts WHERE cart_id = :cart_id")->execute([':cart_id' => $guest_cart_id]);
    }
    unset($_SESSION['guest_cart_id']);
}
}
?>