<?php
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["type"] == "c"){
    $customer_id = $_POST["customer_id"];
    $card_num = $_POST["card_num"];
    $address = $_POST["address"];
    $city = $_POST["city"];
    $postal = $_POST["postal"];
    $state = $_POST["state"];


    require_once("connect-db.php");

    $sql = "UPDATE customers SET card_num = :card_num, address = :address, city = :city, postal = :postal, state = :state WHERE customer_id = :customer_id";


    $statement = $db->prepare($sql);

    $statement->bindValue(":card_num", $card_num);
    $statement->bindValue(":address", $address);
    $statement->bindValue(":city", $city);
    $statement->bindValue(":postal", $postal);
    $statement->bindValue(":state", $state);
    $statement->bindValue(":customer_id", $customer_id);

    if($statement->execute()){
        $statement->closeCursor();

        $customerMessage = "<h4>Your Billing has been Updated. You will be redirected</h4>";
        ?>
        <script>
            window.location.href = 'checkout.php?updated=2';
        </script>
    <?php
    }else{
        $customerMessage = "<h4>There was a problem updateing your Billing.</h4>";
    }
}
?>