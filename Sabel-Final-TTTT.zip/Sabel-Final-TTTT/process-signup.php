<?php
session_start();
require_once ("connect-db.php");

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $customername = $_POST["customername"];
    $customeremail = $_POST["customeremail"];
    $customerusername = $_POST["customerusername"];
    $customerpassword = $_POST["customerpassword"];
    $card_num = $_POST["card_num"];
    $address = $_POST["address"];
    $city = $_POST["city"];
    $postal = $_POST["postal"];
    $state = $_POST["state"];

    $hashed_password = password_hash($customerpassword, PASSWORD_DEFAULT);

    try{
        $sql = "insert into customers (customername, customeremail, customerusername, customerpassword, card_num, address, city, postal, state) values (:customername, :customeremail, :customerusername, :customerpassword, :card_num, :address, :city, :postal, :state)";
        $stmt = $db->prepare($sql);
        
        $stmt->bindParam(':customername', $customername);
        $stmt->bindParam(':customeremail', $customeremail);
        $stmt->bindParam(':customerusername', $customerusername);
        $stmt->bindParam(':customerpassword', $hashed_password);
        $stmt->bindParam(':card_num', $card_num);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':city', $city);
        $stmt->bindParam(':postal', $postal);
        $stmt->bindParam(':state', $state);

        if($stmt->execute()){
            ?>
            <script>
            setTimeout(function() {
                window.location.href = 'login.php';
            }, 3000);
            </script>
            <?php
        } else {
            echo "Error creating account.";
        }
        $stmt = null;
    } catch (PDOException $e){
        echo "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.php"?>
        <article>
            <h2>Customer Account</h2>
            <h5>The account has been created! You will be redirected in 3 seconds.</h5>
        </article>
        
        <?php include "footer_taco.html"?>
    </div>
</body>
</html>