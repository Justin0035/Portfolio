$(document).ready(function(){
    // Use for slideshow on index
    let currentIndex = 0; 
    let slides = $(".slides");
    let totalSlides = slides.length;  
    let autoSlide = setInterval(nextSlide, 5000); 
    var autoSliding = true;  

    function showSlide(index){
        slides.removeClass("active").hide();  
        slides.eq(index).addClass("active").fadeIn(); 
    }

    function nextSlide() {
        currentIndex = (currentIndex + 1) % totalSlides; 
        showSlide(currentIndex); 
    }

    function prevSlide() {
        currentIndex = (currentIndex - 1 + totalSlides) % totalSlides; 
        showSlide(currentIndex);
    }

    function stopAutoSlide() {
        if (autoSliding) { 
            clearInterval(autoSlide);  
            autoSliding = false; 
        }
    }

    $(".next").click(function() { 
        stopAutoSlide(); 
        nextSlide();
        console.log(`CurrentIndex: ${currentIndex}`); 
    });

    $(".prev").click(function() {  
        stopAutoSlide(); 
        prevSlide(); 
        console.log(`CurrentIndex: ${currentIndex}`);
    });

});