<?php
session_start();
require_once("connect-db.php");

$customer_id = $_SESSION['customer_id'] ?? null;
$session_id = $_SESSION['guest_cart_id'] ?? null;

if (!$customer_id && !$session_id) {
    $session_id = bin2hex(random_bytes(16));
    $_SESSION['guest_cart_id'] = $session_id;
}

if ($customer_id) {
    $sql = "SELECT * FROM carts WHERE customer_id = :customer_id";
    $statement = $db->prepare($sql);
    $statement->bindValue(":customer_id", $customer_id);
} else {
    $sql = "SELECT * FROM carts WHERE session_id = :session_id";
    $statement = $db->prepare($sql);
    $statement->bindValue(":session_id", $session_id);
}
$statement->execute();
$cart = $statement->fetch();

if (!$cart) {
    echo "<p>No cart found.</p>";
    exit;
}

$cart_id = $cart['cart_id'];

$sql = "SELECT ci.cart_item_id, ci.quantity, f.food_id, food_name, food_price
        FROM cart_items ci
        JOIN food f ON ci.food_id = f.food_id
        WHERE ci.cart_id = :cart_id";
$statement = $db->prepare($sql);
$statement->bindValue(":cart_id", $cart_id);
$statement->execute();
$items = $statement->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    if (!$customer_id) {
        echo "<p>You must be logged in to checkout.</p>";
        exit;
    }

    $sql = "INSERT INTO orders (customer_id) VALUES (:customer_id)";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(":customer_id", $customer_id);
    $stmt->execute();
    $order_id = $db->lastInsertId();

    $sql = "INSERT INTO order_item (order_id, food_id, quantity) VALUES (:order_id, :food_id, :quantity)";
    $stmt = $db->prepare($sql);
    foreach ($items as $item) {
        $stmt->execute([
            ":order_id" => $order_id,
            ":food_id" => $item['food_id'],
            ":quantity" => $item['quantity']
        ]);
    }

    $db->prepare("DELETE FROM cart_items WHERE cart_id = :cart_id")->execute([':cart_id' => $cart_id]);

    echo "<script>alert('Order placed successfully!'); window.location.href = 'orders.php';</script>";
    exit;
}
if($customer_id){

    $sql = "select * from customers where customer_id = :customer_id";
    $statement = $db->prepare($sql);
    $statement->bindValue(":customer_id", $customer_id);

    if($statement->execute()){
        $customers = $statement->fetchAll();
        $statement->closeCursor();
        $message = "<h3>Items successfully retrieved.</h3>";
    }else{
        $message = "<h3>Error retrieving items.</h3>";
    }        
}else{
    echo "<h4>Error getting information.</h4>";
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Checkout - Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css">
</head>
<body>
<div class="container">
    <?php include "header_nav.php"; ?>
    <article>
        <h2>Order Review</h2>
        <?php if (isset($_GET['updated']) && $_GET['updated'] == 2): ?>
            <p style="color: green; font-weight: bold;">Account Billing Updated.</p>
        <?php endif; ?>
        <?php if (count($items) > 0): ?>
            <table cellpadding="10" cellspacing="0">
                <thead>
                    <tr>
                        <th>Food</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $total = 0;
                    foreach ($items as $item): 
                        $subtotal = $item['quantity'] * $item['food_price'];
                        $total += $subtotal;
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($item['food_name']) ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td>$<?= number_format($item['food_price'], 2) ?></td>
                        <td>$<?= number_format($subtotal, 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td colspan="3" style="text-align:right"><strong>Total:</strong></td>
                        <td><strong>$<?= number_format($total, 2) ?></strong></td>
                    </tr>
                </tbody>
            </table>
            <br><a class="checkout checkleft"  href="cart.php">Back to Cart</a>
            <form action="process-checkout.php" method="POST">
                <input type="hidden" name="cart_id" value="<?= $cart_id ?>">
                <input type="hidden" name="total" value="<?= $total ?>">
                <button type="submit" class="checkout checkmove" >Place Order</button>
            </form><br>

        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
        <h2>Update Billing Information</h2>
            <?php if (isset($_GET['updated']) && $_GET['updated'] == 1): ?>
                <p style="color: green; font-weight: bold;">Account Information Updated.</p>
            <?php endif; ?>
            <!-- takes you to a different userupdate page (just for billing updates) -->
            <form action="process-userbillupdate.php" method="POST">
            <?php
            foreach($customers as $c){
                ?>
                <label>Card Number:</label><br>
                <input type="text" name="card_num" value="<?php echo $c["card_num"];?>" pattern="^\d{4}$" required><br>
                <input type="hidden" name="customer_id" value="<?php echo $c["customer_id"];?>">
                <input type="hidden" name="type" value="c">
                <label>Address:</label><br>
                <input type="text" name="address" value="<?php echo $c["address"];?>" required><br>
                <label>City:</label><br>
                <input type="text" name="city" value="<?php echo $c["city"];?>" required><br>
                <label>Postal:</label><br>
                <input type="text" name="postal" value="<?php echo $c["postal"];?>" pattern="^\d{5,6}$" required><br>
                <label>State:</label><br>
                <input type="text" name="state" value="<?php echo $c["state"];?>" pattern="^[A-Za-z]*$" required><br><br>
                <input class="subch" type="submit" value="Update User">
                <?php } ?>
            </form>
    </article>
    <?php include "footer_taco.html"; ?>
</div>
</body>
</html>