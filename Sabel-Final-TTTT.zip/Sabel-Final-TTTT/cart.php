<?php
session_start();
require_once("connect-db.php");

$customer_id = $_SESSION['customer_id'] ?? null;
$session_id = $_SESSION['guest_cart_id'] ?? null;

// session use for guest cart
if (!$customer_id && !$session_id) {
    $session_id = bin2hex(random_bytes(16));
    $_SESSION['guest_cart_id'] = $session_id;
}

if ($customer_id) {
    $sql = "SELECT * FROM carts WHERE customer_id = :customer_id";
    $statement = $db->prepare($sql);
    $statement->bindValue(":customer_id", $customer_id);
} else {
    $sql = "SELECT * FROM carts WHERE session_id = :session_id";
    $statement = $db->prepare($sql);
    $statement->bindValue(":session_id", $session_id);
}
$statement->execute();
$cart = $statement->fetch();


if (!$cart) {
    $sql = "INSERT INTO carts (customer_id, session_id) VALUES (:customer_id, :session_id)";
    $statement = $db->prepare($sql);
    $statement->bindValue(":customer_id", $customer_id);
    $statement->bindValue(":session_id", $session_id);
    $statement->execute();
    $cart_id = $db->lastInsertId();
} else {
    $cart_id = $cart['cart_id'];
}


$sql = "SELECT ci.cart_item_id, ci.quantity, food_name, food_price
        FROM cart_items ci
        JOIN food f ON ci.food_id = f.food_id
        WHERE ci.cart_id = :cart_id";
$statement = $db->prepare($sql);
$statement->bindValue(":cart_id", $cart_id);
$statement->execute();
$items = $statement->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.php"?>
        <article>
            <!-- let the user know when you remove something from the cart -->
            <h2 class="cartclass">Your Cart</h2>
            <?php if (isset($_GET['removed']) && $_GET['removed'] == 1): ?>
                <p style="color: red; font-weight: bold;">Item removed from cart.</p>
            <?php endif; ?>
            <?php if (count($items) > 0): ?>
    <?php 
    $total = 0;
    ?>
    <table cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>Order Choice</th>
                <th>Quantity</th>
                <th>Price Each</th>
                <th>Subtotal</th>
                <th>Action</th>
            </tr>
        </thead>
            <tbody>
            <?php foreach ($items as $item): 
                $subtotal = $item['food_price'] * $item['quantity'];
                $total += $subtotal;
            ?>
                <tr>
                    <td><strong><?= htmlspecialchars($item['food_name']) ?></strong></td>
                    <td><?= $item['quantity'] ?></td>
                    <td>$<?= number_format($item['food_price'], 2) ?></td>
                    <td>$<?= number_format($subtotal, 2) ?></td>
                    <td>
                        <form method="POST" action="remove-cartitem.php">
                            <input type="hidden" name="cart_item_id" value="<?= $item['cart_item_id'] ?>">
                            <button class="removebutton" type="submit">Remove</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <!--buttons-->
                 <tr>
                    <td colspan="5"><a class="moremenu" href="menu.php">Add More Items</a></td>
                </tr>
                <tr>
                    <td colspan="3" style="text-align:right"><strong>Total:</strong></td>
                    <td colspan="2"><strong>$<?= number_format($total, 2) ?></strong></td>
                </tr>
                <?php 
                    if (isset($_SESSION['customer-login'])) {
                        ?>
                    <tr>
                        <td colspan="5"><a class="checkout" href="checkout.php">Proceed to Checkout</a></td>
                    <tr>
                <?php
                    } else {
                        ?>
                    <tr>
                        <td colspan="5"><a class="checkout" href="login.php">Login to Checkout</a></td>
                    <tr>
                <?php } ?>
            </tfoot>
        </table>

        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>

        </article>
        
        <?php include "footer_taco.html"?>
    </div>
</body>
</html>
