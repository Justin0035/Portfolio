<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="external.js"></script>
</head>

<body>
    <div class="container">
        <?php include "header_nav.php"?>
        <article>
            <div class="slideshow-container">
                <img class="slides active first" src="images/taco1.jpg" alt="slide 1">
                <img class="slides first" src="images/burrito4.jpg" alt="slide 2">
                <img class="slides first" src="images/taco6.jpg" alt="slide 3">

                <button class="prev">&#10094;</button>
                <button class="next">&#10095;</button>
            </div>
                <h2 id="title">Ted's Top Tacos</h2>
                <div class="blockfav">
                    <div class="blocksection">
                        <div class="blockimg"><img src="images/taco3.jpg" alt="Ted's Tops"></div>
                        <div class="blocktext">Salad</div>
                    </div>
                    <div class="blocksection">
                        <div class="blockimg"><img src="images/taco5.jpg" alt="Ted's Tops"></div>
                        <div class="blocktext">Chesse fries</div>
                    </div>
                    <div class="blocksection">
                        <div class="blockimg"><img src="images/burrito2.jpg" alt="Ted's Tops"></div>
                        <div class="blocktext">Mini Steak</div>
                    </div>
                </div>
                <div class="menubutton">
                    <h3 class="centermenu"><a href="menu.php">Full Menu</a></h3>
                </div>
        </article>
        
        <?php include "footer_taco.html"?>
    </div>
</body>
</html>
