<?php
session_start();
require_once("connect-db.php");

$customer_id = $_SESSION['customer_id'] ?? null;

if (!$customer_id) {
    echo "<script>alert('You must be logged in to place an order.'); window.location.href = 'login.php';</script>";
    exit;
}

$sql = "SELECT * FROM carts WHERE customer_id = :customer_id";
$statement = $db->prepare($sql);
$statement->bindValue(":customer_id", $customer_id);
$statement->execute();
$cart = $statement->fetch();

if (!$cart) {
    echo "<script>alert('No cart found.'); window.location.href = 'menu.php';</script>";
    exit;
}

$cart_id = $cart['cart_id'];

$sql = "SELECT ci.quantity, f.food_id
        FROM cart_items ci
        JOIN food f ON ci.food_id = f.food_id
        WHERE ci.cart_id = :cart_id";
$statement = $db->prepare($sql);
$statement->bindValue(":cart_id", $cart_id);
$statement->execute();
$items = $statement->fetchAll();

if (count($items) === 0) {
    echo "<script>alert('Your cart is empty.'); window.location.href = 'cart.php';</script>";
    exit;
}

$sql = "INSERT INTO orders (customer_id) VALUES (:customer_id)";
$statement = $db->prepare($sql);
$statement->bindValue(":customer_id", $customer_id);
$statement->execute();
$order_id = $db->lastInsertId();

$sql = "INSERT INTO order_items (order_id, food_id, quantity) VALUES (:order_id, :food_id, :quantity)";
$statement = $db->prepare($sql);

foreach ($items as $item) {
    $statement->execute([
        ':order_id' => $order_id,
        ':food_id' => $item['food_id'],
        ':quantity' => $item['quantity']
    ]);
}

$db->prepare("DELETE FROM cart_items WHERE cart_id = :cart_id")->execute([':cart_id' => $cart_id]);

echo "<script>alert('Order placed successfully!'); window.location.href = 'menu.php';</script>";
exit;
?>