<?php
session_start();

    if(!isset($_SESSION['customer-login'])){
        header("Location: menu.php");
        exit();
    }
    $message = "";
    require_once("connect-db.php");

    $customer_id = $_SESSION['customer_id'] ?? null;

    if($customer_id){

        $sql = "select * from customers where customer_id = :customer_id";
        $statement = $db->prepare($sql);
        $statement->bindValue(":customer_id", $customer_id);

        if($statement->execute()){
            $customers = $statement->fetchAll();
            $statement->closeCursor();
            $message = "<h3>Items successfully retrieved.</h3>";
        }else{
            $message = "<h3>Error retrieving items.</h3>";
        }        
    }else{
        echo "<h4>Error getting information.</h4>";
    }
    $sql = "SELECT * FROM orders WHERE customer_id = :customer_id ORDER BY order_id DESC";
    $statement = $db->prepare($sql);
    $statement->bindValue(":customer_id", $customer_id);
    $statement->execute();
    $orders = $statement->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.php"?>
        <article>

            <h1>Settings</h1>
            <h5>Here you can change your account settings.</h5>
            <?php if (isset($_GET['updated']) && $_GET['updated'] == 1): ?>
                <p style="color: green; font-weight: bold;">Account Information Updated.</p>
            <?php endif; ?>
            <form action="process-userupdate.php" method="POST">
            <?php
            foreach($customers as $c){
                ?>
                <label>Customer Name:</label><br>
                <input type="text" name="customername" value="<?php echo $c['customername']; ?>" required><br>
                <label>Email:</label>
                <input type="hidden" name="customer_id" value="<?php echo $c["customer_id"];?>"><br>
                <input type="hidden" name="type" value="c">
                <input type="text" name="customeremail" value="<?php echo $c["customeremail"];?>" required><br>
                <label>UserName:</label><br>
                <input type="text" name="customerusername" value="<?php echo $c["customerusername"];?>" required><br>
                <label>Password:</label><br>
                <input type="password" name="customerpassword" placeholder="Enter new password" ><br><br>
                <label>Card Number:</label><br>
                <input type="text" name="card_num" value="<?php echo $c["card_num"];?>" pattern="^\d{4}$" required><br>
                <label>Address:</label><br>
                <input type="text" name="address" value="<?php echo $c["address"];?>" required><br>
                <label>City:</label><br>
                <input type="text" name="city" value="<?php echo $c["city"];?>" required><br>
                <label>Postal:</label><br>
                <input type="text" name="postal" value="<?php echo $c["postal"];?>" pattern="^\d{5,6}$" required><br>
                <label>State:</label><br>
                <input type="text" name="state" value="<?php echo $c["state"];?>" pattern="^[A-Za-z]*$" required><br><br>
                <input class="subch" type="submit" value="Update User">
                <?php } ?>
            </form>

            <h1>Past Orders</h1>
            <h5>Here you can view your past orders.</h5>
            <?php if (count($orders) > 0): ?>
                <?php $counter = 1; ?>
                <?php foreach ($orders as $order): ?>
                    <div class="order-summary">
                        <h3>Order #<?= $counter++ ?></h3>
                        <?php
                            $orderSql = "SELECT oi.quantity, f.food_name, f.food_price 
                                         FROM order_items oi 
                                         JOIN food f ON oi.food_id = f.food_id 
                                         WHERE oi.order_id = :order_id";
                            $orderStmt = $db->prepare($orderSql);
                            $orderStmt->bindValue(":order_id", $order['order_id']);
                            $orderStmt->execute();
                            $items = $orderStmt->fetchAll();

                            $orderTotal = 0;
                            foreach ($items as $item):
                                $subtotal = $item['food_price'] * $item['quantity'];
                                $orderTotal += $subtotal;
                        ?>
                            <li>
                                <?= htmlspecialchars($item['food_name']) ?> x <?= $item['quantity'] ?> 
                                - $<?= number_format($subtotal, 2) ?>
                            </li>
                        <?php endforeach; ?>
                        <strong><br>Total: $<?= number_format($orderTotal, 2) ?></strong>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>You have not placed any orders yet.</p>
            <?php endif; ?>

        </article>
        
        <?php include "footer_taco.html"?>
    </div>
</body>
</html>