<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.php";?>
        <article>
            <form action="process-addmenu.php" method="POST">
                <!-- Add new Food Item -->
                <h2>Add new Food:</h2>
                <label>Image Path:</label><br>
                <!--Only allow me to add image (local to my computer)-->
                <input type="file" name="food_img" accept="image/*" required><br><br>
                <label>Category:</label><br>
                <label><input class="inline" type="radio" name="food_cat" value="tacos" required>Tacos</label>
                <label><input class="inline" type="radio" name="food_cat" value="burritos">Burritos</label>
                <label><input class="inline" type="radio" name="food_cat" value="quesadillas">Quesadillas</label>
                <label><input class="inline" type="radio" name="food_cat" value="sides">Sides</label>
                <label><input class="inline" type="radio" name="food_cat" value="drinks">Drinks</label><br><br>
                <label>Food Name:</label><br>
                <input type="text" name="food_name" required><br>
                <label>Price:</label><br>
                <input type="text" name="food_price" required pattern="^[0-9.,]+$" required><br>
                <label>Food Description:</label><br>
                <input type="text" name="food_desc" required><br>
                <label>Calories:</label><br>
                <input type="text" name="food_cal" required pattern="^[0-9]+$" required><br><br>
                <label>Status:</label><br>
                <label><input class="inline" type="radio" name="status" value="Active" required>Active</label>
                <label><input class="inline" type="radio" name="status" value="Out">Remove</label><br><br>
                <input class="subch" type="submit" value="Add Food">
            </form>
        </article>
        <?php include "footer_taco.html";?>
    </div>
</body>
</html>