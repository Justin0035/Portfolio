<?php
session_start();

    if(!isset($_SESSION['admin-login'])){
        header("Location: menu.php");
        exit();
    }
    $customerMessage = "";

if($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["type"] == "f"){
        $food_id = $_POST["food_id"];
        $food_img = $_POST["food_img"];
        $food_cat = $_POST["food_cat"];
        $food_name = $_POST["food_name"];
        $food_price = $_POST["food_price"];
        $food_desc = $_POST["food_desc"];
        $food_cal = $_POST["food_cal"];
        $status = $_POST["status"];

        require_once("connect-db.php");

        $sql = "UPDATE food SET food_img = :food_img, food_cat = :food_cat, food_name = :food_name, food_price = :food_price, food_desc = :food_desc, food_cal = :food_cal, status = :status where food_id = :food_id";

        $statement = $db->prepare($sql);

        $statement->bindValue(":food_img", $food_img);
        $statement->bindValue(":food_cat", $food_cat);
        $statement->bindValue(":food_name", $food_name);
        $statement->bindValue(":food_price", $food_price);
        $statement->bindValue(":food_desc", $food_desc);
        $statement->bindValue(":food_cal", $food_cal);
        $statement->bindValue(":food_id", $food_id);
        $statement->bindValue(":status", $status);

        if($statement->execute()){
            $statement->closeCursor();

            $customerMessage = "<h4>Your Menu Item has been Updated. You will be redirected</h4>";
            ?>
            <script>
                window.location.href = 'adminmenu.php';
            </script>
        <?php
        }else{
            $customerMessage = "<h4>There was a problem Updateing you Menu Item.</h4>";
        }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>

</body>
</html>