<?php
session_start();

    if(!isset($_SESSION['admin-login'])){
        header("Location: menu.php");
        exit();
    }
    $message = "";
    require_once("connect-db.php");

    $food_id = isset($_GET["food_id"]) ? $_GET["food_id"] : null;

    if($food_id){

        $sql = "select * from food where food_id = :food_id";
        $statement = $db->prepare($sql);
        $statement->bindValue(":food_id", $food_id);

        if($statement->execute()){
            $food = $statement->fetchAll();
            $statement->closeCursor();
            $message = "<h3>Items successfully retrieved.</h3>";
        }else{
            $message = "<h3>Error retrieving items.</h3>";
        }        
    }else{
        echo "<h4>Error getting information.</h4>";
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.php"?>
        <article>
            <h2>Update Menu Item</h2>
            <form action="process-foodupdate.php" method="POST">
            <?php
            foreach($food as $f){
                ?>
                <label>Image Path:</label><br>
                <input type="text" name="food_img" value="<?php echo $f['food_img']; ?>" required><br><br>
                <label>Category:</label>
                <input type="hidden" name="food_id" value="<?php echo $f["food_id"];?>">
                <input type="hidden" name="type" value="f">
                <label><input type="radio" name="food_cat" value="tacos" <?php if($f["food_cat"] == "tacos") {?> checked="checked" <?php } ?> required>Tacos</label>
                <label><input type="radio" name="food_cat" value="burritos" <?php if($f["food_cat"] == "burritos") {?> checked="checked" <?php } ?> required>Burritos</label>
                <label><input type="radio" name="food_cat" value="quesadillas" <?php if($f["food_cat"] == "quesadillas") {?> checked="checked" <?php } ?> required>Quesadillas</label>
                <label><input type="radio" name="food_cat" value="sides" <?php if($f["food_cat"] == "sides") {?> checked="checked" <?php } ?> required>Sides</label>
                <label><input type="radio" name="food_cat" value="drinks" <?php if($f["food_cat"] == "drinks") {?> checked="checked" <?php } ?> required>Drinks</label><br><br>
                <label>Food Name:</label><br>
                <input type="text" name="food_name" value="<?php echo $f["food_name"];?>" required><br>
                <label>Price:</label><br>
                <input type="text" name="food_price" value="<?php echo $f["food_price"];?>" required pattern="^[0-9.,]+$" required><br>
                <label>Food Description:</label><br>
                <input type="text" name="food_desc" value="<?php echo $f["food_desc"];?>" required><br>
                <label>Calories:</label><br>
                <input type="text" name="food_cal" value="<?php echo $f["food_cal"];?>" required pattern="^[0-9]+$" required><br>
                <label>Status:</label><br>
                <label><input class="inline" type="radio" name="status" value="Active" <?php if($f["status"] == "Active") {?> checked="checked" <?php } ?> required>Active</label>
                <label><input class="inline" type="radio" name="status" value="Out" <?php if($f["status"] == "Out") {?> checked="checked" <?php } ?> required>Remove</label><br><br>
                <input class="subch" type="submit" value="Update Food">
                <?php } ?>
            </form>
        </article>

        <?php include "footer_taco.html"?>
    </div>
</body>
</html>