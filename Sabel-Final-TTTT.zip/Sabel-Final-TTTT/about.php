<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ted's Tacos</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.php"?>
        <article><br>
        <h3>Welcome to Ted's Tacos, where we serve the best tacos in town! Our menu features a variety of delicious options, including classic tacos, burritos, quesadillas, and more. Whether you're in the mood for something spicy or something mild, we've got you covered. Don't forget to check out our drink specials and sides to complete your meal!</h3>
            <div class="cardgroup rightside">
                <img src="images/hand1.jpg" class="reimg" alt="Handing out Tacos"><!--https://www.eatthis.com/best-fast-food-tacos/-->
                <div class="card-body">
                    <h3 class="card-text">Giving Back</h3>
                    <p class="card-text">At Ted's Tacos we always believe in giving back in the community.</p><br>
                </div>
            </div>
            <div class="cardgroup">
                <img src="images/hand2.jpg" class="reimg" alt="Handing out Tacos"><!--https://wearefoundations.org/2024/02/dudes-t-a-c-o-s-growing-connecting-helping-men-live-well/#-->
                <div class="card-body">
                    <h3 class="card-text">Ted's Team</h3>
                    <p class="card-text">Celebating 10 years at Fondy Axe Company!</p><br>
                </div>
            </div>
                <br>
        </article>
        
        <?php include "footer_taco.html"?>
    </div>
</body>
</html>