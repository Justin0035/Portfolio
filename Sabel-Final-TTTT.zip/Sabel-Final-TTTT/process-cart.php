<?php
session_start();
require_once("connect-db.php");

$food_id = $_POST['food_id']; 
$quantity = $_POST['quantity'] ?? 1;

if (isset($_SESSION['customer_id'])) {
    $customer_id = $_SESSION['customer_id'];
    $sql = "SELECT cart_id FROM carts WHERE customer_id = :customer_id";
    $statement = $db->prepare($sql);
    $statement->bindValue(":customer_id", $customer_id);
    $statement->execute();
    $cart = $statement->fetch();
} else {
    
    if (!isset($_SESSION['guest_cart_id'])) {
        // gives guest a id
        $_SESSION['guest_cart_id'] = bin2hex(random_bytes(16)); 
    }
    $session_id = $_SESSION['guest_cart_id'];
    $sql = "SELECT cart_id FROM carts WHERE session_id = :session_id";
    $statement = $db->prepare($sql);
    $statement->bindValue(":session_id", $session_id);
    $statement->execute();
    $cart = $statement->fetch();
}

if (!$cart) {
    if (isset($customer_id)) {
        $sql = "INSERT INTO carts (customer_id) VALUES (:customer_id)";
        $statement = $db->prepare($sql);
        $statement->bindValue(":customer_id", $customer_id);
    } else {
        $sql = "INSERT INTO carts (session_id) VALUES (:session_id)";
        $statement = $db->prepare($sql);
        $statement->bindValue(":session_id", $session_id);
    }
    $statement->execute();
    $cart_id = $db->lastInsertId();
} else {
    $cart_id = $cart['cart_id'];
}

$sql = "SELECT * FROM cart_items WHERE cart_id = :cart_id AND food_id = :food_id";
$statement = $db->prepare($sql);
$statement->bindValue(":cart_id", $cart_id);
$statement->bindValue(":food_id", $food_id);
$statement->execute();
$existingItem = $statement->fetch();

if ($existingItem) {
    $sql = "UPDATE cart_items SET quantity = quantity + :quantity WHERE cart_id = :cart_id AND food_id = :food_id";
} else {
    $sql = "INSERT INTO cart_items (cart_id, food_id, quantity) VALUES (:cart_id, :food_id, :quantity)";
}
$statement = $db->prepare($sql);
$statement->bindValue(":cart_id", $cart_id);
$statement->bindValue(":food_id", $food_id);
$statement->bindValue(":quantity", $quantity);
$statement->execute();


header("Location: cart.php");
exit;

?>
