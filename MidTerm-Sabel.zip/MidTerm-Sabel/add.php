<?php ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>D&B Realty</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header-nav.html";?>
        <article>
            <form action="add-insert.php" method="POST">
                <!-- Add new Home -->
                <h3>Add new home:</h3>
                <label>Image Path:</label><br>
                <input type="file" name="imagep" accept="image/*" required><br>
                <label>Price:</label><br>
                <input type="text" name="price" required><br>
                <label>Bedrooms:</label><br>
                <input type="text" name="bedroom" required><br>
                <label>Bathrooms:</label><br>
                <input type="text" name="bath" required><br>
                <label>Home sq ft:</label><br>
                <input type="text" name="homesqfeet" required><br>
                <label>Land sq ft:</label><br>
                <input type="text" name="landsqfeet" required><br>
                <label>Address:</label><br>
                <input type="text" name="address" required><br>
                <label>City:</label><br>
                <input type="text" name="city" required><br>
                <label>State:</label><br>
                <input type="text" name="state" required><br>
                <label>Hoa Fees:</label><br>
                <input type="text" name="monthlyfee" required><br>
                <label>Property Type:</label>
                <label><input class="inline" type="radio" name="propertytype" value="family" required>Single Family</label>
                <label><input class="inline" type="radio" name="propertytype" value="condo">Condo</label>
                <label><input class="inline" type="radio" name="propertytype" value="land">Land</label><br>
                <label>Status:</label>
                <label><input class="inline" type="radio" name="status" value="market" required>Market</label>
                <label><input class="inline" type="radio" name="status" value="sold">Sold</label><br><br>
                <input class="subch" type="submit" value="Add the property">
            </form>
        </article>
        <?php include "footer.html";?>
    </div>
</body>

</html>