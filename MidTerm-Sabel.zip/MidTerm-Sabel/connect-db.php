<?php
$servername = "mysql:host=localhost;dbname=d&b_realty";
$username = "root";
$password = "";

try {
    $db = new PDO($servername, $username, $password);
    }
catch (PDOException $e) 
    {
    echo "Connection failed: " . $e->getMessage();
    }

?>