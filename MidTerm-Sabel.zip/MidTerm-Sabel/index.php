<?php
    $message = "";
    require_once("connect-db.php");

    // random home //
    $sql = "select * from home where status = 'market' order by RAND() Limit 1";

    $statement = $db->prepare($sql);

    if($statement->execute()){
        $home = $statement->fetch(PDO::FETCH_ASSOC);
        $statement->closeCursor();
        $message = "<h3>Homes successfully retrieved.</h3>";
    }else{
        $message = "<h3>Error retrieving Homes.</h3>";
        $home = null;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>D&B Realty</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header-nav.html";?>
        <section>
            <p>Dirk and Benji are two realtor brothers in California. They strive to make the process of buying home or property easy! Dirk and Benji have are both highly experienced, both having 15 years in the housing industry. What is a realtor you might ask? Well a realtor is a person who acts as an agent for the sale and purchase of building and land, in particular a member of the National Association of Realtors; a real estate agent. The next time you need a realtor, give Dirk and Benji a try! </p>
        </section>
        <main>
            <p id="homesale">Featured Home</p>
            <table>
                <?php if ($home):?>
                <tr>
                    <!-- Show random home for sale on the Market -->
                    <td><img src="<?php echo htmlspecialchars('images/' . $home['imagep']); ?>" alt="Home"></td>
                    <td id="hometext">$<?php echo number_format($home["price"], 2); echo "<br>";?>
                    <?php echo $home["bedroom"];?> bed 
                    <?php echo "<br>"; echo $home["bath"];?> bath
                    <?php echo "<br>"; echo $home["homesqfeet"];?> sq feet
                    <?php echo "<br>"; echo $home["landsqfeet"];?> sq foot lot
                    <?php echo "<br>"; echo $home["address"]; echo " "; echo $home["city"]; echo ", "; echo $home["state"]; echo "<br>";?>
                    Property Type: <?php echo $home["propertytype"]; echo "<br>";?>
                    Hoa Fees: $<?php echo $home["monthlyfee"]; echo "/mo<br>";?>
                    <form action="contact.php" method="GET">
                        <input type="hidden" name="home_id" value ="<?php echo $home["home_id"];?>">
                        <button type="submit">Request More Information</button>
                        </form></td>
                </tr>
                <?php else: ?>
                <tr><td colspan="2">No homes available.</td></tr>
                <?php endif; ?>
            </table>
            
        </main>
        <?php include "footer.html";?>
    </div>
</body>

</html>
