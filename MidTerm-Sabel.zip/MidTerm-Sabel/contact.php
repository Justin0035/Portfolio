<?php
    $message = "";
    require_once("connect-db.php");

    $home_id = isset($_GET["home_id"]) ? $_GET["home_id"] : null;

    if($home_id){

        $sql = "select * from home where home_id = :home_id";
        $statement = $db->prepare($sql);
        $statement->bindValue(":home_id", $home_id);

        if($statement->execute()){
            $home = $statement->fetchAll();
            $statement->closeCursor();
            $message = "<h3>Home successfully retrieved.</h3>";
        }else{
            $message = "<h3>Error retrieving Home.</h3>";
        }        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>D&B Realty</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header-nav.html";?>
        <main>
            <p id="homesale">Request More Information On this Home</p>
            <table>
                <!-- Get data from the house you selected -->
                <?php
                foreach($home as $h){
                    ?>
                <tr>
                    <td><input type="hidden" name="home_id" value ="<?php echo $f["home_id"];?>">
                    <input type="hidden" name="type" value ="h">
                    <td><img src="<?php echo htmlspecialchars('images/' . $h['imagep']); ?>" alt="Home"></td>
                    <td id="hometext">$<?php echo number_format($h["price"], 2); echo "<br>";?>
                    <?php echo $h["bedroom"];?> bed 
                    <?php echo "<br>"; echo $h["bath"];?> bath
                    <?php echo "<br>"; echo $h["homesqfeet"];?> sq feet
                    <?php echo "<br>"; echo $h["landsqfeet"];?> sq foot lot
                    <?php echo "<br>"; echo $h["address"]; echo " "; echo $h["city"]; echo ", "; echo $h["state"]; echo "<br>";?>
                    Property Type: <?php echo $h["propertytype"]; echo "<br>";?>
                    Hoa Fees: $<?php echo $h["monthlyfee"]; echo "/mo<br>";?>
                    </td>
                    <?php } ?>
                </tr>
                    <?php
                }
                ?>
            </table>


            <form action="form-submission.php" method="POST">
                <!-- User contact with house select -->
                <h3>Tell us about yourself...</h3>
                <label>First Name:</label><br>
                <input type="text" name="first" required><br>
                <label>Last Name:</label><br>
                <input type="text" name="last" required><br>
                <label>Email:</label><br>
                <input type="email" name="email" required><br>
                <label>Phone:</label><br>
                <input type="tel" name="phone" required><br>
                <label>Phone Type:</label>
                <label><input class="inline" type="radio" name="phonetype" value="home" required>Home Phone</label>
                <label><input class="inline" type="radio" name="phonetype" value="cell">Cell Phone</label>
                <label><input class="inline" type="radio" name="phonetype" value="work">Work Phone<br><br></label>
                <label>Message:</label><br>
                <input type="text" name="message"><br>
                <h3>What are you looking for?</h3>
                <label>Type of Home:</label>
                <input class="inline" type="hidden" name="type[]" value="">
                <label><input class="inline" type="checkbox" name="type[]" value="family">Single Family</label>
                <label><input class="inline" type="checkbox" name="type[]" value="condo">Condo</label>
                <label><input class="inline" type="checkbox" name="type[]" value="land">Land<br></label>
                <label>Price Range:</label>
                <label><input class="inline" type="radio" name="price" value="0" required>$0.00-$100,000.00</label>
                <label><input class="inline" type="radio" name="price" value="100">$100,000.00-$250,000.00</label>
                <label><input class="inline" type="radio" name="price" value="250">$250,000.00-$500,000.00</label>
                <label><input class="inline" type="radio" name="price" value="500">$500,000.00+</label><br><br>
                <input class="subch" type="submit" value="Add the property">
            </form>
        </main>
        <?php include "footer.html";?>
    </div>
</body>