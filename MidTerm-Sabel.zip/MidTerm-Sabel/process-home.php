<?php
    $customerMessage = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
        $home_id = $_POST["home_id"];
        $imagep = $_POST["imagep"];
        $price = $_POST["price"];
        $bedroom = $_POST["bedroom"];
        $bath = $_POST["bath"];
        $homesqfeet = $_POST["homesqfeet"];
        $landsqfeet = $_POST["landsqfeet"];
        $address = $_POST["address"];
        $city = $_POST["city"];
        $state = $_POST["state"];
        $monthlyfee = $_POST["monthlyfee"];
        $propertytype = $_POST["propertytype"];
        $status = $_POST["status"];
        $success = true;

        require_once("connect-db.php");
        // update home data in database //
        $sql = "UPDATE home SET imagep = :imagep, price = :price, bedroom = :bedroom, bath = :bath, homesqfeet = :homesqfeet, landsqfeet = :landsqfeet, address = :address, city = :city, state = :state, monthlyfee = :monthlyfee, propertytype = :propertytype, status = :status WHERE home_id = :home_id";

        $statement = $db->prepare($sql);

        $statement->bindValue(":home_id", $home_id);
        $statement->bindValue(":imagep", $imagep);
        $statement->bindValue(":price", $price);
        $statement->bindValue(":bedroom", $bedroom);
        $statement->bindValue(":bath", $bath);
        $statement->bindValue(":homesqfeet", $homesqfeet);
        $statement->bindValue(":landsqfeet", $landsqfeet);
        $statement->bindValue(":address", $address);
        $statement->bindValue(":city", $city);
        $statement->bindValue(":state", $state);
        $statement->bindValue(":monthlyfee", $monthlyfee); 
        $statement->bindValue(":propertytype", $propertytype);
        $statement->bindValue(":status", $status);

        if($statement->execute()){
            $statement->closeCursor();

            $customerMessage = "<h4>Your Home has been updates. </h4>";
            ?>
            <script>
                // Go back to home For sale page //
                window.location.href = 'home-list.php';
            </script>
        <?php
        }else{
            $customerMessage = "<h4>There was a problem adding your donut.</h4>";
        }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>D&B Realty</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>

</body>
</html>