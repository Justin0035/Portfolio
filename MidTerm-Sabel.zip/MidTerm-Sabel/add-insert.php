<?php
    $customerMessage = "";

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $imagep = $_POST["imagep"];
        $price = $_POST["price"];
        $bedroom = $_POST["bedroom"];
        $bath = $_POST["bath"];
        $homesqfeet = $_POST["homesqfeet"];
        $landsqfeet = $_POST["landsqfeet"];
        $address = $_POST["address"];
        $city = $_POST["city"];
        $state = $_POST["state"];
        $monthlyfee = $_POST["monthlyfee"];
        $propertytype = $_POST["propertytype"];
        $status = $_POST["status"];
        $success = true;
    }
    else{
        echo "<h4>Error getting information.</h4>";
    }

if($success){
        require_once("connect-db.php");
        // insert date into database //
        $sql = "insert into home (imagep, price, bedroom, bath, homesqfeet, landsqfeet, address, city, state, monthlyfee, propertytype, status) values (:imagep, :price, :bedroom, :bath, :homesqfeet, :landsqfeet, :address, :city, :state, :monthlyfee, :propertytype, :status)";

        $statement = $db->prepare($sql);

        $statement->bindValue(":imagep", $imagep);
        $statement->bindValue(":price", $price);
        $statement->bindValue(":bedroom", $bedroom);
        $statement->bindValue(":bath", $bath);
        $statement->bindValue(":homesqfeet", $homesqfeet);
        $statement->bindValue(":landsqfeet", $landsqfeet);
        $statement->bindValue(":address", $address);
        $statement->bindValue(":city", $city);
        $statement->bindValue(":state", $state);
        $statement->bindValue(":monthlyfee", $monthlyfee); 
        $statement->bindValue(":propertytype", $propertytype);
        $statement->bindValue(":status", $status);

        if($statement->execute()){
            $statement->closeCursor();

            $customerMessage = "<h4>You request has been submitted. Home have been added to database!</h4>";
            ?>
            <script>
                // Go back to home-list.php //
                window.location.href = 'home-list.php';
            </script>
        <?php
        }else{
            $customerMessage = "<h4>There was a problem adding your request.</h4>";
        }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>D&B Realty</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>

</body>

</html>