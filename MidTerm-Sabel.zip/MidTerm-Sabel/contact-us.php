<?php ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>D&B Realty</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header-nav.html";?>
        <main>
            <form action="no-choice-form-submission.php" method="POST">
                <!-- User contact (no house selected) -->
                <h3>Tell us about yourself...</h3>
                <label>First Name:</label><br>
                <input type="text" name="first" required><br>
                <label>Last Name:</label><br>
                <input type="text" name="last" required><br>
                <label>Email:</label><br>
                <input type="email" name="email" required><br>
                <label>Phone:</label><br>
                <input type="tel" name="phone" required><br>
                <label>Phone Type:</label>
                <label><input class="inline" type="radio" name="phonetype" value="home" required>Home Phone</label>
                <label><input class="inline" type="radio" name="phonetype" value="cell">Cell Phone</label>
                <label><input class="inline" type="radio" name="phonetype" value="work">Work Phone<br></label>
                <label>Message:</label><br>
                <input type="text" name="message"><br>
                <h3>What are you looking for?</h3>
                <label>Type of Home:</label>
                <input class="inline" type="hidden" name="type[]" value="">
                <label><input class="inline" type="checkbox" name="type[]" value="family">Single Family</label>
                <label><input class="inline" type="checkbox" name="type[]" value="condo">Condo</label>
                <label><input class="inline" type="checkbox" name="type[]" value="land">Land<br></label>
                <label>Price Range:</label>
                <label><input class="inline" type="radio" name="price" value="0" required>$0.00-$100,000.00</label>
                <label><input class="inline" type="radio" name="price" value="100">$100,000.00-$250,000.00</label>
                <label><input class="inline" type="radio" name="price" value="250">$250,000.00-$500,000.00</label>
                <label><input class="inline" type="radio" name="price" value="500">$500,000.00+</label><br><br>
                <input class="subch" type="submit" value="Add the property">
            </form>
        </main>
        <?php include "footer.html";?>
    </div>
</body>

</html>