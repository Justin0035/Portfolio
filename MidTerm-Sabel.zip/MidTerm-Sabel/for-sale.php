<?php
    $message = "";
    require_once("connect-db.php");

    $sql = "select * from home where status = 'market'";

    $statement = $db->prepare($sql);

    if($statement->execute()){
        $home = $statement->fetchAll();
        $statement->closeCursor();
        $message = "<h3>Homes successfully retrieved.</h3>";
    }else{
        $message = "<h3>Error retrieving Homes.</h3>";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>D&B Realty</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header-nav.html";?>
        <main>
            <p id="homesale">Homes For Sale</p>
            <!-- Show All homes for sale on the Market -->
            <table>
                <?php
                    foreach($home as $h){
                        ?>
                <tr>
                    <td><img src="<?php echo htmlspecialchars('images/' . $h['imagep']); ?>" alt="Home"></td>
                    <td id="hometext">$<?php echo number_format($h["price"], 2); echo "<br>";?>
                    <?php echo $h["bedroom"];?> bed 
                    <?php echo "<br>"; echo $h["bath"];?> bath
                    <?php echo "<br>"; echo $h["homesqfeet"];?> sq feet
                    <?php echo "<br>"; echo $h["landsqfeet"];?> sq foot lot
                    <?php echo "<br>"; echo $h["address"]; echo " "; echo $h["city"]; echo ", "; echo $h["state"]; echo "<br>";?>
                    Property Type: <?php echo $h["propertytype"]; echo "<br>";?>
                    Hoa Fees: $<?php echo $h["monthlyfee"]; echo "/mo<br>";?>
                    <form action="contact.php" method="GET">
                        <input type="hidden" name="home_id" value ="<?php echo $h["home_id"];?>">
                        <button type="submit">Request More Information</button>
                        </form></td>
                </tr>
                <?php
                }
                ?>
            </table>            
        </main>
        <?php include "footer.html";?>
    </div>
</body>

</html>