<?php
    $customerMessage = "";
    $message = "";
    require_once("connect-db.php");

    $homes = [];

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $first = $_POST["first"];
        $last = $_POST["last"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        $phonetype = $_POST["phonetype"];
        $message = $_POST["message"];
        $type = $_POST["type"];
        $typeExtract = implode(", ", array_slice($type, 1));
        $price = $_POST["price"];
        $success = true;
    }
    else{
        echo "<h4>Error getting information.</h4>";
    }

    if($success){
        require_once("connect-db.php");
        // add customer data to database //
        $sql = "insert into customer (first, last, email, phone, phonetype, message, hometype, price) values (:first, :last, :email, :phone, :phonetype, :message, :type, :price)";

        $statement = $db->prepare($sql);

        $statement->bindValue(":first", $first);
        $statement->bindValue(":last", $last);
        $statement->bindValue(":email", $email);
        $statement->bindValue(":phone", $phone); 
        $statement->bindValue(":phonetype", $phonetype); 
        $statement->bindValue(":message", $message); 
        $statement->bindValue(":type", $typeExtract);
        $statement->bindValue(":price", $price); 

        if($statement->execute()){
            $statement->closeCursor();

            $customerMessage = "<h4>You request has been submitted. We will get back to you as soon as we can!</h4>";
        }else{
            $customerMessage = "<h4>There was a problem adding your request.</h4>";
        }
    $price_min = $price * 0.9;
    $price_max = $price * 1.1;
    // First check if type and price match //
    $sql = "select * from home
            where propertytype = :type and status = 'market'
            and price Between :price_min and :price_max
            order by RAND() Limit 2";
    $statement = $db->prepare($sql);
    $statement->bindValue(":type", $typeExtract);
    $statement->bindValue(":price_min", $price_min);
    $statement->bindValue(":price_max", $price_max);
    $statement->execute();
    $homes = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    // Then check if just type match //
    if (count($homes) < 2){
        $sql = "select * from home
            where propertytype = :type and status = 'market'
            order by RAND() Limit 2";
        $statement = $db->prepare($sql);
        $statement->bindValue(":type", $typeExtract);
        $statement->execute();
        $homes = $statement->fetchAll(PDO::FETCH_ASSOC);
        $statement->closeCursor();
    }
    // Then just show random homes/land/condos //
    if (count($homes) < 2){
        $sql = "select * from home where status = 'market'
            order by RAND() Limit 2";
        $statement = $db->prepare($sql);
        $statement->execute();
        $homes = $statement->fetchAll(PDO::FETCH_ASSOC);
        $statement->closeCursor();
    }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>D&B Realty</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header-nav.html";?>
        <div id="echomess">
            <?php
                echo $customerMessage;
            ?>
        </div>
        <main>
            <p id="homesale">Other options you might like...</p>
            <table>
                <?php if (!empty($homes)): ?>
                    <?php foreach ($homes as $home): ?>
                <tr>
                    <!-- Shows 2 homes that match the type and price range the most-->
                    <td><img src="<?php echo htmlspecialchars('images/' . $home['imagep']); ?>" alt="Home"></td>
                    <td id="hometext">$<?php echo number_format($home["price"], 2); echo "<br>";?>
                    <?php echo $home["bedroom"];?> bed 
                    <?php echo "<br>"; echo $home["bath"];?> bath
                    <?php echo "<br>"; echo $home["homesqfeet"];?> sq feet
                    <?php echo "<br>"; echo $home["landsqfeet"];?> sq foot lot
                    <?php echo "<br>"; echo $home["address"]; echo " "; echo $home["city"]; echo ", "; echo $home["state"]; echo "<br>";?>
                    Property Type: <?php echo $home["propertytype"]; echo "<br>";?>
                    Hoa Fees: $<?php echo $home["monthlyfee"]; echo "/mo<br>";?>
                    <form action="contact.php" method="GET">
                        <input type="hidden" name="home_id" value ="<?php echo $home["home_id"];?>">
                        <button type="submit">Request More Information</button>
                        </form></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
            <tr><td colspan="2">No homes available.</td></tr>
            <?php endif; ?>
            </table>
            
        </main>
        
        <?php include "footer.html";?>
    </div>
</body>

</html>