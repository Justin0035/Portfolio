<?php
    $message = "";
    require_once("connect-db.php");
    // Get home data from previous page //
    $home_id = isset($_GET["home_id"]) ? $_GET["home_id"] : null;


    $sql = "select * from home where home_id = :home_id";
    $statement = $db->prepare($sql);
    $statement->bindValue(":home_id", $home_id);

    if($statement->execute()){
        $home = $statement->fetchAll();
        $statement->closeCursor();
        $message = "<h3>Items successfully retrieved.</h3>";
    }else{
        $message = "<h3>Error retrieving items.</h3>";
    }        
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>D&B Realty</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header-nav.html";?>
        <article>
            <form action="process-home.php" method="POST">
                <?php foreach($home as $h){ ?>
                <h3>Update Home:</h3>
                <!-- echo data from the house you selected but can be updated-->
                <input type="hidden" name="home_id" value ="<?php echo $h["home_id"];?>">
                <input type="hidden" name="type" value ="h">
                <label>Image Path:</label><br>
                <input type="text" name="imagep" value="<?php echo $h['imagep']; ?>" required><br>
                <label>Price:</label><br>
                <input type="text" name="price" value="<?php echo $h["price"];?>" required><br>
                <label>Bedrooms:</label><br>
                <input type="text" name="bedroom" value="<?php echo $h["bedroom"];?>" required><br>
                <label>Bathrooms:</label><br>
                <input type="text" name="bath" value="<?php echo $h["bath"];?>" required><br>
                <label>Home sq ft:</label><br>
                <input type="text" name="homesqfeet" value="<?php echo $h["homesqfeet"];?>" required><br>
                <label>Land sq ft:</label><br>
                <input type="text" name="landsqfeet" value="<?php echo $h["landsqfeet"];?>" required><br>
                <label>Address:</label><br>
                <input type="text" name="address" value="<?php echo $h["address"];?>" required><br>
                <label>City:</label><br>
                <input type="text" name="city" value="<?php echo $h["city"];?>" required><br>
                <label>State:</label><br>
                <input type="text" name="state" value="<?php echo $h["state"];?>" required><br>
                <label>Hoa Fees:</label><br>
                <input type="text" name="monthlyfee" value="<?php echo $h["monthlyfee"];?>" required><br>
                <label>Property Type:</label>
                <label><input class="inline" type="radio" name="propertytype" value="family" <?php if($h["propertytype"] == "family") {?> checked="checked" <?php } ?> required>Single Family</label>
                <label><input class="inline" type="radio" name="propertytype" value="condo" <?php if($h["propertytype"] == "condo") {?> checked="checked" <?php } ?>>Condo</label>
                <label><input class="inline" type="radio" name="propertytype" value="land" <?php if($h["propertytype"] == "land") {?> checked="checked" <?php } ?>>Land</label><br>
                <label>Status:</label>
                <label><input class="inline" type="radio" name="status" value="market" <?php if($h["status"] == "market") {?> checked="checked" <?php } ?> required>Market</label>
                <label><input class="inline" type="radio" name="status" value="sold" <?php if($h["status"] == "sold") {?> checked="checked" <?php } ?>>Sold</label><br><br>
                <input type="submit" value="Add the property">
                <?php } ?>
            </form>
        </article>
        <?php include "footer.html";?>
    </div>
</body>

</html>