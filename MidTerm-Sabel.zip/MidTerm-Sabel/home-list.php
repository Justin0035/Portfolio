<?php
    $message = "";
    require_once("connect-db.php");
    // all homes //
    $sql = "select * from home";

    $statement = $db->prepare($sql);

    if($statement->execute()){
        $home = $statement->fetchAll();
        $statement->closeCursor();
        $message = "<h3>Homes successfully retrieved.</h3>";
    }else{
        $message = "<h3>Error retrieving Homes.</h3>";
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>D&B Realty</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header-nav.html";?>
        <main>
            <form id="centerbutton" action="add.php" method="POST">
            <input class="biggerbutton" type="submit" value="Add Home">
            </form>
            <p id="homesale">All Homes</p>
            <table>
                <?php
                    foreach($home as $h){
                        ?>
                <tr>
                    <!-- Show all homes market and sold for admin -->
                    <td><img src="<?php echo htmlspecialchars('images/' . $h['imagep']); ?>" alt="Home"></td>
                    <td id="hometext">$<?php echo number_format($h["price"], 2); echo "<br>";?>
                    <?php echo $h["bedroom"];?> bed 
                    <?php echo "<br>"; echo $h["bath"];?> bath
                    <?php echo "<br>"; echo $h["homesqfeet"];?> sq feet
                    <?php echo "<br>"; echo $h["landsqfeet"];?> sq foot lot
                    <?php echo "<br>"; echo $h["address"]; echo " "; echo $h["city"]; echo ", "; echo $h["state"]; echo "<br>";?>
                    Property Type: <?php echo $h["propertytype"]; echo "<br>";?>
                    Hoa Fees: $<?php echo $h["monthlyfee"]; echo "/mo<br>";?>
                    <!-- add status and make button update/sold-->
                    Status: <?php echo ucwords($h["status"]); echo "<br>";?>
                    <form action="update.php" method="GET">
                        <input type="hidden" name="home_id" value ="<?php echo $h["home_id"];?>">
                        <button type="submit">Update/Sold</button> 
                        </form></td>
                </tr>
                <?php
                }
                ?>
            </table> 
        </main>
        <?php include "footer.html";?>
    </div>
</body>

</html>