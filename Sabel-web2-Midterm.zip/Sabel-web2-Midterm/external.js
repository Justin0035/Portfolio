/* 
Questions:
1. I always link my javascript file in the head of my html.
2. When I'm injecting javascipt into a html file I put the <script> at the bottom
of the body. but before the </body>
3. DOM is the structure for Programming. It's like a tree with the html being the roots
then head/body and so on each on indenting
4. DOM events are actions or occurrences that javascript listena and respond to
Like click, scroll, mouseover and etc.
5. A Javascript library is pre-written code that helps simplifes tasks.
jQuery is an example of a javascript library

*/
// document.write() 1
document.write("Welcome!<br>");
// document.write() 2
document.write("To Rick's Roadhouse<br>");
// document.write() 3
document.write("Take A Look");

$(document).ready(function(){
    // Variable Scope Differences 1 Let, 
    let currentIndex = 0;  // track current slide index
    let slides = $(".slides");  // objects and constructors 1 (jQuery Object)
    let totalSlides = slides.length;  // Total slides
    let autoSlide = setInterval(nextSlide, 5000); 
     // Variable Scope Differences 2 var
    var autoSliding = true;  

    // Invoke Function Expression 1
    function showSlide(index){
        slides.removeClass("active").hide();  // jQuery hide 1
        slides.eq(index).addClass("active").fadeIn(); // jQuery fade 1
    }

    // Invoke Function Expression 2, Closure 1
    function nextSlide() {
        currentIndex = (currentIndex + 1) % totalSlides; 
        showSlide(currentIndex); 
    }

    // Invoke Function Expression 3, Closure 2
    function prevSlide() {
        currentIndex = (currentIndex - 1 + totalSlides) % totalSlides; 
        showSlide(currentIndex);
    }
    // Closure 3
    function stopAutoSlide() {
        if (autoSliding) { 
            clearInterval(autoSlide);  
            autoSliding = false; 
        }
    }

    // jQuery Event Handler 1, jQuery Event 1, Anonymous Function 1
    $(".next").click(function() { 
        stopAutoSlide(); 
        nextSlide();
        // Template String 1, console.log() 1
        console.log(`CurrentIndex: ${currentIndex}`); 
    });

    // jQuery Event Handler 2, jQuery Event 2, Anonymous Function 2
    $(".prev").click(function() {  
        stopAutoSlide(); 
        prevSlide(); 
        // Template String 2, console.log() 2
        console.log(`CurrentIndex: ${currentIndex}`);
    });
    // JavaScript event handlers 1
    document.querySelectorAll(".prev, .next").forEach(button => {
        button.addEventListener("mouseover", () => {
        // Change Class DOM 1, Use get, set, add, remove methods (add) 1
            button.classList.add("hovered");
        });
        // // Use get, set, add, remove methods (remove) 2
        button.addEventListener("mouseout", () => {
            button.classList.remove("hovered");
        });
    });

    // jQuery Event Handler 3, jQuery Event 3, jQuery Callback 1
    $(".blocksection").hover(
        function (){ // Anonymous Function 3
            // jQuery Animate 1, jQuery stop 1
            $(this).stop(true, true).animate({ // jQuery Chaining 1
                width: "500px",
                height: "auto"
            }, 600);  
            // jQuery Animate 2, jQuery stop 2
            $(this).find("img").stop(true, true).animate({
                width: "100%",
                height: "100%"
            }, 600); 
        },
        function (){  
            // jQuery Animate 3, jQuery stop 3
            $(this).stop(true, true).animate({
                width: "400px",
                height: "auto"
            }, 300);

            $(this).find("img").stop(true, true).animate({
                width: "100%",
                height: "100%"
            }, 300); 
        }
    );

    
    $("#close").click(function(){ 
        $("#open").slideToggle("slow");  // jQuery Slide 1, jQuery Callback 2
        // console.log() 3
        console.log("Open About");
    });
    // jQuery hide/show 2
    $("footer").hide();
    // jQuery hide/show 3
    setTimeout(function(){
        $("footer").show();
    }, 2000);
    // JavaScript event handlers 2
    $("footer").click(function(){  
        $(this).css("animation", "none");  // jQuery Callback 3, jQuery CSS 1
        console.log("Stop animation");
    });

    // Arrow function 3, JavaScript event handlers 3
    document.querySelectorAll("main h2").forEach(h2 => {
        // Change attribute DOM 1
        h2.setAttribute("style", "color: white; text-align: center; font-size: 2.5em");
        // Javascript event listeners 2
        $("h2").mouseover(function() {
            // jQuery css 3
            $(this).css("color", "gold");
        });
        // Javascript event listeners 3
        $("h2").mouseout(function() {
            // jQuery css 3
            $(this).css("color", "white");
        });
    });

    document.querySelectorAll(".menu1").forEach(section => {
        // objects and constructors 2 (Style Object)
        section.style.cssText = "background-color: orange; padding: 10px; border-radius: 10px";
    });
    document.querySelectorAll(".giftimg").forEach(img =>{
        img.style.cssText = "width: 100%; height: 450px; display: flex; color: white; font-size: 1.75em; justify-content: center; align-items: center; background: url('images/gift4.jpg') no-repeat; background-size: cover;";
    });
    // Use get, set, add, remove methods (set) 3
    $(".giftimg").attr("alt", "Giving a Gift");
    document.querySelectorAll(".giftcards img").forEach(img => {
        // Change attribute DOM 2
        img.setAttribute("alt", "Gift card image");
        img.setAttribute("width", "300px");
        img.setAttribute("height", "400px");
    });
    document.querySelectorAll(".giftcards").forEach(img => {
        img.style.cssText = "display: flex; justify-content: space-evenly;";
    });
    const giftText = document.querySelector("#gifttext");
    if(giftText){
        giftText.style.cssText = "display: flex; justify-content: center; text-align: center; margin-bottom: 20px; font-size: 1.5em; color: white;";
    }
    var giftcardscount = 0;
    $(".giftcards img").click(
        function () {
            //jQuery Slide 2
            $(this).slideToggle(1000);
            giftcardscount += 1;
    });
    document.querySelectorAll(".buygift").forEach(text => {
        text.style.cssText = "display: flex; justify-content: center; font-size: 1.5em; color: white;";
    });
    //jQuery Slide 3
    $(".restartbutton").click(
        function () {
            //jQuery Slide 3, jQuery fade 2, jQuery Chaining 2
            $(".giftcards img").fadeIn(1000).slideToggle(500).slideToggle(500);
            // Template Strings 3
            console.log(`Reset Giftcards, Current Count: ${giftcardscount}`);
            giftcardscount = 0;
    });
    
    const aboutMessage = ["We are a family owned business that has been serving the community for over 20 years.<br>", "We take pride in our food and service and strive to make every customer feel like they are part of the family.<br>", "Our menu is full of delicious options that are sure to please everyone in your party.<br>", "We look forward to serving you soon!"];
    const abouttext = document.getElementById("abouttext");

    if(abouttext){
        // spread operator 1, use the .html, .val, and .text jQuery functions (html) 1
        $("#abouttext").html([...aboutMessage].join(""))
    }
    const homeMessage = ["Rick's Rockstars"];
    const title = document.getElementById("title");

    if(title){
        // spread operator 2, use the .html, .val, and .text jQuery functions (text) 2
        $("#title").text([...homeMessage].join(""))
    }
    const giftMessage = ["Gift cards are available for purchase in any amount<br>", "They make the perfect gift for any occasion<br>", "Stop in today to purchase yours!"];
    const gifttext = document.getElementById("gifttext");
    if(gifttext){
        // spread operator 3, use the .html, .val, and .text jQuery functions (html) 3
        $("#gifttext").html([...giftMessage].join(""))
    }
    
    // Arrow Function 1
    if(window.location.pathname.includes('menu.html')){
        // Javascript event listeners 1
        window.addEventListener("scroll", () => {
            // querySelector method 1, variable Scope Differences 3 const 
            const slideContainer = document.querySelector(".slide-container");
            // Change Class DOM 2
            if (window.scrollY > 200) {
                slideContainer.classList.add("sticky");
            }else{
            // Change Class DOM 3
                slideContainer.classList.remove("sticky");
            }
        });
        // querySeleector 2
        const menuItems = document.querySelectorAll(".slide-container ul li");
        // Arrow Function 2, objects and constructors 3 (event Object)
        menuItems.forEach(item => {
            item.addEventListener("click", (e) => {
                // Change attribute DOM 3
                const targetId = e.target.getAttribute("data-target");
                // querySelector 3
                const targetElement = document.querySelector(targetId);
                window.scrollTo({
                    top: targetElement.offsetTop - 150,
                    behavior: "smooth"
                });
            });
        });
    }
    // jQuery fade 3
    setTimeout(function(){
        // jQuery Chaining 3
        $(".secretcode").css("color", "blue").fadeOut(2000);
    }, 3000);    

});
