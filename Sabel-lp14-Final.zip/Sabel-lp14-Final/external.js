$(document).ready(function(){

    // Spinner Fix A
    $( function() {
      var spinner = $( "#spinner3" ).spinner();
      spinner.spinner()
    });
    // Spinner Fix B
    $( function() {
      var spinner = $( "#spinner4" ).spinner();
      spinner.spinner()
      $( "#setvalue" ).on( "click", function() {
        spinner.spinner( "value", 10 );
      });
    });
    // 10. jQuery Plugin A
    if (document.body.id === "indexPage") {
      var controller = new ScrollMagic.Controller();
      var animateElem = document.querySelector(".animate2");
      var scene = new ScrollMagic.Scene({triggerElement: ".trigger2", duration: 250})
              .on("enter", function () {
                animateElem.style.backgroundColor = "lime";
              })
              .on("leave", function () {
                animateElem.style.backgroundColor = "";
              })
              .addTo(controller);
              
              
      var controller2 = new ScrollMagic.Controller();
      var animateElem2 = document.querySelectorAll(".animate3");
      
      let index = 0;
      // 13. For of Loop A
      for (const elem of animateElem2) {
          var triggerSelector = ".trigger3:nth-of-type(" + (index + 1) + ")";
      
          new ScrollMagic.Scene({
              triggerElement: ".trigger3",
              duration: 250
          })
          .on("enter", function () {
              elem.style.backgroundColor = "yellow";
          })
          .on("leave", function () {
              elem.style.backgroundColor = "";
          })
          .addTo(controller2);
      
          index++;
      }
      // 10. jQuery Plugin B        
      $('.tooltip').tooltipster({
        delay: 400,
        animation: 'fade'
      });
    }
    // 9. Tabs A
    $("#tabs").tabs();
    // 9. Tabs B
    $("#tabs2").tabs();

    // 12. Use of Sets A
    const sheetcakes = new Set();
      
    $('.sheetclick').on('click', function() {
      const imageId = $(this).data('img-id');
      sheetcakes.add(imageId);
      window.location.href = `custom.html?id=${imageId}`;
      console.log([...sheetcakes]);
    });

    // 7. Dialog A
    // Dialog popup after checkout
    $( function() {
      $( "#checkoutDialog" ).dialog({
        autoOpen: false
      })
    });
    // Dialog popup after feedback
    $( function() {
      $( "#checkoutDialog2" ).dialog({
        autoOpen: false
      })
    });


    $(function () {
      function getQueryParam(param) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
      }
    
      if (getQueryParam("checkout") === "success") {
        $("#checkoutDialog").dialog("open");
    
        history.replaceState({}, document.title, window.location.pathname);
      }
      else if (getQueryParam("checkout") === "feedback") {
        $("#checkoutDialog2").dialog("open");
    
        history.replaceState({}, document.title, window.location.pathname);
      }
    });

    getData();

    function getData() {
      $.ajax({
        // 14. JSON file
        // 14. JSON call 1
        url: "employee.json",
        success: function(jsonData) {
          let html = "";
    
          jsonData.forEach((employee, index) => {
            if (index % 3 === 0) {
              html += `<div class="w-100"></div>`; 
            }
    
            html += `
              <div class="col-md-4 mb-4 text-center">
                <div class="card h-100 shadow-sm">
                  <img src="${employee.image}" class="card-img-top imgresize" alt="Image of ${employee.name}">
                  <div class="card-body">
                    <h5 class="card-title">${employee.name}</h5>
                    <p class="card-text">${employee.title}<br>
                    <strong>${employee.experience}</strong></p>
                  </div>
                </div>
              </div>
            `;
          });
    
          $("#display_area").html(html);
        }
      });
    }

    // 11. Use of Maps A
    let employeeMap = new Map();

    makeemployeemap(function() {

      console.log(employeeMap.get("Ben Fletcher")); 
    });
    
    function makeemployeemap(callback) {
      $.ajax({
        // 14. JSON file
        // 14. JSON call 2
        url: "employee.json",
        success: function(jsonData) {
          jsonData.forEach((employee) => {
              employeeMap.set(employee.name, employee);
          });
          callback();
        }
      });
    }
    // 7. Dialog B
    // Dialog popup if feedback is a duplicate
    $( function() {
      $( "#dialog" ).dialog({
        autoOpen: false
      })
    } );
    // 11. Use of Maps B
    let groupfeedback = new Map();
    // 12. Use of Sets B
    const feedbackcount = new Set();
    $("#addResponse").click(function() {
      const cake = $("#cakeInput").val().trim();
      const topping = $("#toppingInput").val().trim();
      const groups = topping.split(",").map(group => group.trim());

      if(groupfeedback.has(cake)){
          $("#dialog").dialog("open");
          return;
      }

      groupfeedback.set(cake, groups);
      feedbackcount.add(cake);
      console.log([...feedbackcount]);

      $("#cakeInput").val("");
      $("#toppingInput").val("");

      displayCakefeedback();
    });

      function displayCakefeedback() {
          const cakelist = $("#cakesandtopping");
          cakelist.empty();
          
          // 13. For of Loop B
          for (const [cake, topping] of groupfeedback) {
            const cakeLi = $("<div>");
          
            const cakeHeader = $("<h2>").text(`Cake Type: ${cake}`);
            cakeLi.append(cakeHeader);
          
            const toppingList = $("<ul>");
            for (const t of topping) {
              const toppingItem = $("<li>").text(t);
              toppingList.append(toppingItem);
            }
              cakeLi.append(toppingList);

              cakelist.append(cakeLi);

          };
      }


      const params = new URLSearchParams(window.location.search);
      const imageId = params.get('id');
  
      if (imageId) {
        document.getElementById('cake-image').src = `images/${imageId}.jpg`;
      }
      // 4. SelectMenu A
      $( "#size" ).selectmenu();
      // 4. SelectMenu B
      $( "#flavor" ).selectmenu();

      $( function() {
        const labels = {
            0: "No",
            100: "Yes"
          };
        var handle = $( "#custom-handle" );
        // 1. Slider A
        $( "#slider" ).slider({
            min: 0,
            max: 100,
            step: 100,
          create: function() {
            handle.text(labels[$(this).slider("value")]);
          },
          slide: function( event, ui ) {
            handle.text(labels[ui.value]);
          }
        });
      });
      $( function() {
        const labels = {
            0: "No",
            100: "Yes"
          };
        var handle = $( "#custom-handle2" );
        // 1. Slider B
        $( "#slider2" ).slider({
            min: 0,
            max: 100,
            step: 100,
          create: function() {
            handle.text(labels[$(this).slider("value")]);
          },
          slide: function( event, ui ) {
            handle.text(labels[ui.value]);
          }
        });
      });
      $( function() {
        var spinner = $( "#spinner" ).spinner();
        spinner.spinner( "disable" );
        spinner.spinner("value", "Buttercreme Style");

        // 2. Spinner A
        $( "#setvalue" ).on( "click", function() {
          spinner.spinner( "value", "Buttercreme Style" );
        });
         // 2. Spinner B
        $( "#setvalue2" ).on( "click", function() {
            spinner.spinner( "value", "Whipped" );
          });
     
        $( "button" ).button();

      });
        // 5. Progressbar A
        $( function() {
        $( "#progressbar" ).progressbar({
            value: 33
            });
        });
        // 5. Progressbar B
        $( function() {
            $( "#progressbar2" ).progressbar({
                value: 67
            });
        });
      // 6. Autocomplete A
      $( function() {
        var availableTags = [
          "Happy Birthday",
          "Happy Anniversary",
          "Congratulations",
          "Best Wishes",
          "Happy Holidays",
          "Welcome Home",
          "I Love You",
          "You're the Best",
          "Forever & Always",
          "Thinking of You",
          "BFFs Forever",
          "You Did It",
          "You Rock",
          "You're Amazing",
          "Treasure This Moment",
          "Just Because",
          "#Blessed",
          "Cake Time",
          "Celebrate Good Times",
        ];
        $( "#tags" ).autocomplete({
          source: availableTags
        });
      } );
      
    // 6. Autocomplete B
      $( function() {
        var availableTags2 = [
            "12:00 AM",
            "1:00 AM",
            "2:00 AM",
            "3:00 AM",
            "4:00 AM",
            "5:00 AM",
            "6:00 AM",
            "7:00 AM",
            "8:00 AM",
            "9:00 AM",
            "10:00 AM",
            "11:00 AM",
            "12:00 PM",
            "1:00 PM",
            "2:00 PM",
            "3:00 PM",
            "4:00 PM",
            "5:00 PM",
            "6:00 PM",
            "7:00 PM",
            "8:00 PM",
            "9:00 PM",
            "10:00 PM",
            "11:00 PM",
        ];
        $( "#tags2" ).autocomplete({
          source: availableTags2
        });
      } );
      // 8. Datepicker A
      $( function() {
        $( "#datepicker" ).datepicker();
      } );
      // 8. Datepicker B
      $( function() {
        $( "#datepicker2" ).datepicker();
      } );
      // 3. Accordion A
      $( function() {
        $( "#accordion" ).accordion();
      } );
      // 3. Accordion B
      $( function() {
        $( "#accordion2" ).accordion();
      } );
      $( function() {
        $( "#accordion3" ).accordion();
      } );


});