<!DOCTYPE html>
<html lang="en">

<?php
    $customerMessage = "";

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $coffee = $_POST["coffee"];
        $strength = $_POST["strength"];
        $price = $_POST["price"];
        $pounds = $_POST["pounds"];
        $success = true;
    }
    else{
        echo "<h4>Error getting information.</h4>";
    }

if($success){
        require_once("connect-db.php");

        $sql = "insert into coffee (coffee, strength, price, pounds) values (:coffee, :strength, :price, :pounds)";
        
        $statement = $db->prepare($sql);

        $statement->bindValue(":coffee", $coffee);
        $statement->bindValue(":strength", $strength); 
        $statement->bindValue(":price", $price);
        $statement->bindValue(":pounds", $pounds);

        if($statement->execute()){
            $statement->closeCursor();

            $customerMessage = "<h4>Your coffee has been added! You will be redirected in 5 seconds.</h4>";
            ?>
            <script>
                setTimeout(function(){
                    window.location.href = 'food-list.php';
                }, 5000);
            </script>
        <?php
        }else{
            $customerMessage = "<h4>There was a problem adding your coffee.</h4>";
        }
    }
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dirk's Donuts</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.html";?>
        <article>
            <h2>Request Results</h2>
            <?php
                echo $customerMessage;
            ?>
            <?php
                echo "<h2>New Coffee</h2>";
                echo "<h4>Coffee Name: $coffee</h4>";
                echo "<h4>Coffee Strength: $strength</h4>";
                echo "<h4>Coffee Price: $price</h4>";
                echo "<h4>Coffee Lbs: $pounds</h4>";
            ?>


        </article>
        
        <footer>
            <h3>Dirk's Donuts</h3>
        </footer>
    </div>
</body>

</html>