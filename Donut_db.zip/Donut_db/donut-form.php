<!DOCTYPE html>
<htm lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dirk's Donuts</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.html";?>
        <article>
            <h2>Add a New Dount</h2>
                <form action="donut-insert.php" method="POST">
                    <label>Dount Name:</label>
                    <input class="pad" type="text" name="donut" required>
                    <label>Dount Flavor:</label>
                    <input class="pad" type="text" name="flavor" required>
                    <label>Dount Price:</label>
                    <input class="pad" type="text" name="price">
                    <label>Dount Toppings:</label>
                    <input class="inline" type="hidden" name="top[]" value="">
                    <input class="inline" type="checkbox" name="top[]" value="Sprinkles"><label>Sprinkles</label>
                    <input class="inline" type="checkbox" name="top[]" value="Nuts"></label>Nuts</label>
                    <input class="inline" type="checkbox" name="top[]" value="Cookies"></label>Cookies<br><br></label>
                    <label>Donut Quantity:<br></label>
                    <select name="quantity">
                    <option value = "">Choose one!</option>
                    <option value = "12">12</option>
                    <option value = "24">24</option>
                    <option value = "36">36</option>
                    </select>
                    <input class="subch" type="submit" value="Add the Donut">
                </form>

        </article>
        
        <footer>
            <h3>Dirk's Donuts</h3>
        </footer>
    </div>
</body>

</html>