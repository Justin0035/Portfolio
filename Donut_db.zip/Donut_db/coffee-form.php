<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dirk's Donuts</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.html";?>
        <article>
            <h2>Add New Coffee</h2>
                <form action="coffee-insert.php" method="POST">
                    <label>Coffee Name:</label>
                    <input class="pad" type="text" name="coffee" required>
                    <label>Coffee Strength:</label>
                    <input class="pad" type="text" name="strength" required>
                    <label>Coffee Price:</label>
                    <input class="pad" type="text" name="price">
                    <label>Coffee Lbs:<br></label>
                    <select name="pounds">
                    <option value = "">Choose one!</option>
                    <option value = "1">1</option>
                    <option value = "2">2</option>
                    <option value = "3">3</option>
                    </select>
                    <input class="subch" type="submit" value="Add the coffee">
                </form>


        </article>
        
        <footer>
            <h3>Dirk's Donuts</h3>
        </footer>
    </div>
</body>

</html>