<!DOCTYPE html>
<html lang="en">

<?php
    $customerMessage = "";

if($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["type"] == "d"){
        $donut_id = $_POST["donut_id"];
        $donut = $_POST["donut"];
        $flavor = $_POST["flavor"];
        $price = $_POST["price"];
        $top = $_POST["top"];
        $topExtract = implode(", ", $top);
        $quantity = $_POST["quantity"];

        require_once("connect-db.php");

        $sql = "UPDATE donut SET donut = :donut, flavor = :flavor, price = :price, toppings = :top, quantity = :quantity WHERE donut_id = :donut_id";

        $statement = $db->prepare($sql);

        $statement->bindValue(":donut", $donut);
        $statement->bindValue(":flavor", $flavor);
        $statement->bindValue(":price", $price);
        $statement->bindValue(":top", $topExtract);
        $statement->bindValue(":quantity", $quantity);  
        $statement->bindValue(":donut_id", $donut_id);  

        if($statement->execute()){
            $statement->closeCursor();

            $customerMessage = "<h4>Your donut has been added. You will be redirected in 5 seconds.</h4>";
            ?>
            <script>
                setTimeout(function(){
                    window.location.href = 'food-list.php';
                }, 5000);
            </script>
        <?php
        }else{
            $customerMessage = "<h4>There was a problem adding your donut.</h4>";
        }
    
}elseif($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["type"] == "c"){
        $coffee_id = $_POST["coffee_id"];
        $coffee = $_POST["coffee"];
        $strength = $_POST["strength"];
        $price = $_POST["price"];
        $pounds = $_POST["pounds"];
        require_once("connect-db.php");

        $sql = "UPDATE coffee SET coffee = :coffee, strength = :strength, price = :price, pounds = :pounds WHERE coffee_id = :coffee_id";
        
        $statement = $db->prepare($sql);

        $statement->bindValue(":coffee", $coffee);
        $statement->bindValue(":strength", $strength); 
        $statement->bindValue(":price", $price);
        $statement->bindValue(":pounds", $pounds);
        $statement->bindValue(":coffee_id", $coffee_id); 


        if($statement->execute()){
            $statement->closeCursor();

            $customerMessage = "<h4>Your coffee has been added! You will be redirected in 5 seconds.</h4>";
            ?>
            <script>
                setTimeout(function(){
                    window.location.href = 'food-list.php';
                }, 5000);
            </script>
        <?php
        }else{
            $customerMessage = "<h4>There was a problem adding your coffee.</h4>";
        }
    }

?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dirk's Donuts</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.html";?>
        <article>
            <h2>Update the Menu Item</h2>
            <h5>Updated</h5>
        </article>
        <footer>
            <h3>Dirk's Donuts</h3>
        </footer>
    </div>
</body>
