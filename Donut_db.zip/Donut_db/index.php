<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dirk's Donuts</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.html";?>
        <article>

            <img class="donut" src="donut.png">

            <p>Ice cream cake chocolate cake tart tart. Gingerbread wafer cookie halvah brownie biscuit. Cheesecake dragée gingerbread wafer sugar plum sesame snaps. Pastry pastry brownie chocolate tiramisu. Candy caramels halvah sweet roll toffee jelly macaroon sugar plum sugar plum. Cheesecake croissant pastry pudding sweet roll bonbon tootsie roll jelly-o. Pie gummi bears sesame snaps jujubes ice cream. Sweet chocolate bar cookie fruitcake muffin danish jujubes halvah. Caramels cotton candy candy canes halvah cookie chupa chups. Tart ice cream biscuit dragée pie muffin. Wafer pudding icing cheesecake danish. </p>
            <p>Danish bear claw pudding marshmallow. Jelly beans pastry macaroon gummi bears candy canes pie lollipop tart danish. Muffin marzipan cupcake tiramisu caramels chocolate cake bonbon lollipop. Cotton candy cake chocolate soufflé lemon drops chocolate cake. Gummies biscuit dessert. Ice cream sweet roll sugar plum. Sweet roll marshmallow pie caramels. Topping cookie gummi bears lollipop.</p>
            <div id="clear"></div>
        </article>
        
        <footer>
            <h3>Dirk's Donuts</h3>
        </footer>
    </div>
</body>

</html>
