<!DOCTYPE html>
<html lang="en">
<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    require_once("connect-db.php");

    if (isset($_GET["donut_id"])) {
        $item_type = "donut";
        $item_id = $_GET["donut_id"];
        $sql = "DELETE FROM donut WHERE donut_id = :item_id";
    } elseif (isset($_GET["coffee_id"])) {
        $item_type = "coffee";
        $item_id = $_GET["coffee_id"];
        $sql = "DELETE FROM coffee WHERE coffee_id = :item_id";
    }

    if (isset($item_id)) {
        $statement = $db->prepare($sql);
        $statement->bindValue(":item_id", $item_id);

        if ($statement->execute()) {
            $statement->closeCursor();
            echo "<script>window.location.replace('food-list.php');</script>";
            exit();
        } else {
            echo "<h4>There was a problem deleting your $item_type.</h4>";
        }
    }
}
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dirk's Donuts</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.html";?>
        <article>
            <ul>
                <li>Donut - <a href="#" onclick="confirmDelete('donut', 1)">Delete</a></li>
                <li>Coffee - <a href="#" onclick="confirmDelete('coffee', 2)">Delete</a></li>
            </ul>
        </article>
        <footer>
            <h3>Dirk's Donuts</h3>
        </footer>
    </div>
    <script>
            function confirmDelete(type, id){
            if (confirm("Are you sure you want to delete this " + type + "?")) {
                window.location.href = "delete-food.php?" + type + "_id=" + id;
            }
        }
    </script>
</body>
