<!DOCTYPE html>
<html lang="en">>

<?php
    $customerMessage = "";

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $donut = $_POST["donut"];
        $flavor = $_POST["flavor"];
        $price = $_POST["price"];
        $top = $_POST["top"];
        $topExtract = implode(", ", array_slice($top, 1));
        $quantity = $_POST["quantity"];
        $success = true;
        
    }
    else{
        echo "<h4>Error getting information.</h4>";
    }

if($success){
        require_once("connect-db.php");

        $sql = "insert into donut (donut, flavor, price, toppings, quantity) values (:donut, :flavor, :price, :top, :quantity)";

        $statement = $db->prepare($sql);

        $statement->bindValue(":donut", $donut);
        $statement->bindValue(":flavor", $flavor);
        $statement->bindValue(":price", $price);
        $statement->bindValue(":top", $topExtract);
        $statement->bindValue(":quantity", $quantity); 

        if($statement->execute()){
            $statement->closeCursor();

            $customerMessage = "<h4>Your donut has been added. You will be redirected in 5 seconds.</h4>";
            ?>
            <script>
                setTimeout(function(){
                    window.location.href = 'food-list.php';
                }, 5000);
            </script>
        <?php
        }else{
            $customerMessage = "<h4>There was a problem adding your donut.</h4>";
        }
}
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dirk's Donuts</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.html";?>
        <article>
            <h2>Request Results</h2>
            <?php
                echo $customerMessage;
            ?>
            <?php
                echo "<h2>New Donut</h2>";
                echo "<h4>Donut Name: $donut</h4>";
                echo "<h4>Donut Flavor: $flavor</h4>";
                echo "<h4>Donut Price: $price</h4>";
                echo "<h4>Donut Toppings: $topExtract</h4>";
                echo "<h4>Donut Quantity: $quantity</h4>";
            ?>
        </article>
        
        <footer>
            <h3>Dirk's Donuts</h3>
        </footer>
    </div>
</body>

</html>