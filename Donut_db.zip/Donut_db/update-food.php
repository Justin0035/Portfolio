<!DOCTYPE html>
<html lang="en">
<?php
    $message = "";
    require_once("connect-db.php");

    $donut_id = isset($_GET["donut_id"]) ? $_GET["donut_id"] : null;
    $coffee_id = isset($_GET["coffee_id"]) ? $_GET["coffee_id"] : null;

    if($donut_id){

        $sql = "select * from donut where donut_id = :donut_id";
        $statement = $db->prepare($sql);
        $statement->bindValue(":donut_id", $donut_id);

        if($statement->execute()){
            $food = $statement->fetchAll();
            $statement->closeCursor();
            $message = "<h3>Items successfully retrieved.</h3>";
        }else{
            $message = "<h3>Error retrieving items.</h3>";
        }        
    }elseif($coffee_id){

        $sql2 = "select * from coffee where coffee_id = :coffee_id";
        $statement2 = $db->prepare($sql2);
        $statement2->bindValue(":coffee_id", $coffee_id);

        if($statement2->execute()){
            $coffee = $statement2->fetchAll();
            $statement2->closeCursor();
            $message = "<h3>Items successfully retrieved.</h3>";
        }else{
            $message = "<h3>Error retrieving items.</h3>";
        }
    }else{
        echo "<h4>Error getting information.</h4>";
    }
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dirk's Donuts</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.html";?>
        <article>
            <?php if($donut_id): ?>
                <h2>Update Donut</h2>
                <form action="process-food.php" method="POST">
                <?php
                foreach($food as $f){
                    ?>
                    <label>Donut Name:</label>
                    <input type="hidden" name="donut_id" value ="<?php echo $f["donut_id"];?>">
                    <input type="hidden" name="type" value ="d">
                    <input class="pad" type="text" name="donut" value="<?php echo $f["donut"];?>">
                    <label>Donut Flavor:</label>
                    <input class="pad" type="text" name="flavor" value="<?php echo $f["flavor"];?>">
                    <label>Donut Price:</label>
                    <input class="pad" type="text" name="price" value="<?php echo $f["price"];?>">
                    <label>Donut Toppings:</label>
                    <input class="inline" type="checkbox" name="top[]" value="Sprinkles" <?php if(strpos($f["toppings"], "Sprinkles") !== false){?> checked="checked" <?php }?>> Sprinkles
                    <input class="inline" type="checkbox" name="top[]" value="Nuts" <?php if(strpos($f["toppings"], "Nuts") !== false){?> checked="checked" <?php }?>> Nuts
                    <input class="inline" type="checkbox" name="top[]" value="Cookies" <?php if(strpos($f["toppings"], "Cookies") !== false){?> checked="checked" <?php }?>> Cookies<br><br>
                    <label>Donut Quantity:<br></label>
                    <select name="quantity">
                    <option value = "<?php echo $f["quantity"];?>" checked><?php echo $f["quantity"];?></option>
                    <option value = "12">12</option>
                    <option value = "24">24</option>
                    <option value = "36">36</option>
                    </select>
                    <input class="subch" type="submit" value="Update the donut">
                    <?php } ?>
                </form>
            <?php else: ?>
                <h2>Update Coffee</h2>
                <form action="process-food.php" method="POST">
                <?php foreach($coffee as $c){ ?>
                    <label>Coffee Name:</label>
                    <input type="hidden" name="coffee_id" value ="<?php echo $c["coffee_id"];?>">
                    <input type="hidden" name="type" value ="c">
                    <input class="pad" type="text" name="coffee" value="<?php echo $c["coffee"];?>" required>
                    <label>Coffee Strength:</label>
                    <input class="pad" type="text" name="strength" value="<?php echo $c["strength"];?>" required>
                    <label>Coffee Price:</label>
                    <input class="pad" type="text" name="price" value="<?php echo $c["price"];?>">
                    <label>Coffee Lbs:<br></label>
                    <select name="pounds">
                    <option value = "<?php echo $c["pounds"];?>"><?php echo $c["pounds"];?></option>
                    <option value = "1">1</option>
                    <option value = "2">2</option>
                    <option value = "3">3</option>
                    </select>
                    <input class="subch" type="submit" value="Update the coffee">
                    <?php } ?>
                </form>
            <?php endif; ?>
            
        </article>
        
        <footer>
            <h3>Dirk's Donuts</h3>
        </footer>
    </div>

</body>
</html>