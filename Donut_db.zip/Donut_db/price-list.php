<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dirk's Donuts</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.html";?>
        <article>
        <table>
            <tr>
                <td>Base Price of Donut</td>
                <td><?php $dountPrice = 2.12; echo "$".$dountPrice;?></td>
            </tr>
            <tr>
                <td>Each Topping on a Donut</td>
                <td><?php $toppingPrice = 1.02; echo "$".$toppingPrice;?></td>
            </tr>
            <tr>
                <td>Price of a Dount with 3 Toppings Added</td>
                <td><?php echo "$".$dountPrice + 3 * $toppingPrice;?></td>
            </tr>
            <tr>
                <td>Price of Donut with 3 toppings added. Prices per number of toppings.</td>
                <td><?php for($toppings = 1; $toppings <= 3; $toppings++){
                    $totalCost = $dountPrice + ($toppingPrice * $toppings);
                    echo "Dount with $toppings topping(s): $"
                    .number_format($totalCost,2)."<br>";
                }
                ?></td>
            </tr>
            <tr>
                <td>SPIN THE DONUT WHEEL!</td>
                <td></td>
            </tr>
            <tr>
                <td><?php
                    $dount = rand(1,20);
                    $topping = rand(1,10);
                    $total = $dount * $dountPrice + $topping * $toppingPrice;
                    echo "Dount Spin: ".$dount." <br>Topping Spin: ".$topping;?></td>
                <td><?php echo "Promotion Value: $".number_format($total,2); ?></td>
            </tr>

        </table>
        </article>
        
        <footer>
            <h3>Dirk's Donuts</h3>
        </footer>
    </div>

</body>
</html>