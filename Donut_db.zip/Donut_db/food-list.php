<!DOCTYPE html>
<html lang="en">
<?php
    $message = "";
    require_once("connect-db.php");

    $sql1 = "select * from donut";
    $sql2 = "select * from coffee";

    $statement = $db->prepare($sql1);
    // Separate the coffee and donuts then combine them in the table
    $statement2 = $db->prepare($sql2);

    if($statement->execute()){
        $food = $statement->fetchAll();
        $statement->closeCursor();
        $message = "<h3>Items successfully retrieved.</h3>";
    }else{
        $message = "<h3>Error retrieving items.</h3>";
    }
    if($statement2->execute()){
        $coffee = $statement2->fetchAll();
        $statement2->closeCursor();
        $message = "<h3>Items successfully retrieved.</h3>";
    }else{
        $message = "<h3>Error retrieving items.</h3>";
    }
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Dirk's Donuts</title>
    <link rel="stylesheet" href="stylesheet.css" type="text/css">
</head>

<body>
    <div class="container">
        <?php include "header_nav.html";?>
        <article>
        <h2>Food List</h2>
        <?php
            echo $message;
        ?>
        <table>
            <tr>
                <th>Menu Item</th>
                <th>Favor/Strength</th>
                <th>Price</th>
                <th>Quantity/Lbs</th>
                <th></th>
                <th></th>

            </tr>
            <?php
                foreach($food as $f){
                    ?>
            <tr>
                <td><?php echo $f["donut"];?></td>
                <td><?php echo $f["flavor"]; echo "<br>"; echo $f["toppings"];?></td>
                <td>$<?php echo $f["price"];?></td>
                <td><?php echo $f["quantity"];?></td>
                <td><form action="update-food.php" method="GET">
                    <input type="hidden" name="donut_id" value ="<?php echo $f["donut_id"];?>">
                    <button type="submit">Update</button>
                </form></td>
                <td><form id="deleteForm_<?php echo $f["donut_id"]; ?>" action="delete-food.php" method="GET">
                    <input type="hidden" name="donut_id" value="<?php echo $f["donut_id"];?>">
                    <button type="button" onclick="confirmDelete('donut', <?php echo $f['donut_id']; ?>)">Delete</button>
                    </form></td>
            </tr> 
            <?php
            }
            ?>
            <?php
                foreach($coffee as $c){
                    ?>
            <tr>
                <td><?php echo $c["coffee"];?></td>
                <td><?php echo $c["strength"];?></td>
                <td>$<?php echo $c["price"];?></td>
                <td><?php echo $c["pounds"];?></td>
                <td><form action="update-food.php" method="GET">
                    <input type="hidden" name="coffee_id" value ="<?php echo $c["coffee_id"];?>">
                    <button type="submit">Update</button>
                </form></td>
                <td><form id="deleteForm_<?php echo $c["coffee_id"]; ?>" action="delete-food.php" method="GET">
                    <input type="hidden" name="coffee_id" value="<?php echo $c["coffee_id"];?>">
                    <button type="button" onclick="confirmDelete('coffee', <?php echo $c['coffee_id']; ?>)">Delete</button>
                    </form></td>
            </tr>
            <?php
            }
            ?>

        </table>
        </article>
        
        <footer>
            <h3>Dirk's Donuts</h3>
        </footer>
    </div>
    <script>
    function confirmDelete(type, id) {
        if (confirm("Are you sure you want to delete this " + type + "?")) {
            document.getElementById('deleteForm_' + id).submit();
        }
    }
</script>

</body>
</html>